import viktor as vkt
from midas import MidasAPIClass
import plotly.graph_objects as go
import pandas as pd
import networkx as nx
from pprint import pprint
import json
from chart_tools import extract_keys_at_level, get_subject_elems, get_subject_nodes, create_graph, calculate_positions
from chart_tools import assign_colors, plot_graph, get_node_mode,get_design_actions
from datetime import date
from math import atan, cos

from data_classes import SectionGeometry1, Flange1, Web1, Deck, Reinforcement
from unit_registry import ureg
from munch import Munch
from tg_NC_sag import tg_NC_sag
from tg_NC_hog import tg_NC_hog
from tg_C_sag import tg_C_sag
from tg_C_hog import tg_C_hog


def conn_status_warning(params):
    vkt.UserMessage.warning('Check connection to Midas')

def connection_status(params, **kwargs):
        return params.page_1.tab_1.section_1.conn_status

def get_group_list(params, **kwargs):
        if (params.page_2.tab_3.hidden_group_options_list) != None:
             return params.page_2.tab_3.hidden_group_options_list
        else:
             return []
      
def get_static_lc_list(params, **kwargs):
        lc_list = params.page_2.tab_3.static_lc_data
        #print(lc_list)
        item = 0
        options = []
        if (lc_list) != None:
            for lc in lc_list:
                new_item = vkt.OptionListElement(item, lc)
                options.append(new_item)
                item += 1
            #print(options)
            return options
        else:
             return []

def get_section_ID_list(params, **kwargs):
    """Creates a list of design section names for the cross sections in Midas"""
    section_list = []
    for sect_row in params.page_data_from_midas.tab_2.table_1:
        id = f'{sect_row["section_ID"]}: {sect_row["section_name"]}'
        section_list.append(id)
    return section_list

def chart_field(params, **kwargs):
     #print(params.page_2.tab_3.chart_field_visibility)
     return True

def lc_default(params):
    #print(params.page_2.tab_3.default_static_lc)
    return '1: SW'
    #return str(params.page_2.tab_3.default_static_lc)

def act_units(params, **kwargs):
    #midas_obj = MidasAPIClass(params.page_1.tab_1.section_2.base_url, params.page_1.tab_1.section_2.mapi_key)
    current_units = params.page_2.tab_3.unit_data
    if current_units != None:
        act_unitsv = current_units[0]["UNIT"]['1']['FORCE'] + ',' + current_units[0]["UNIT"]['1']['DIST'] + ',' + \
                    current_units[0]["UNIT"]['1']['TEMPER']
        return act_unitsv
    else:
        return ''

class Parametrization(vkt.Parametrization):
    _node_data = {}
    page_1 = vkt.Page('Setup')
    page_1.tab_1 = vkt.Tab('Information')
    page_1.tab_1.section_1 = vkt.Section('How to use')
    page_1.tab_1.section_1.input_1 = vkt.Text('Describe how to use the application')
    page_1.tab_1.section_1.conn_status = vkt.TextField('', default='Press the Connect API button', visible=False)

    page_1.tab_1.section_2 = vkt.Section('Midas Connection')
    page_1.tab_1.section_2.base_url = vkt.TextField('Midas Base URL')
    page_1.tab_1.section_2.mapi_key = vkt.TextField('Midas MAPI-Key')
    page_1.tab_1.section_2.conn_btn = vkt.SetParamsButton('Connect API', method='connect_API')
    page_1.tab_1.section_2.conn_status = vkt.OutputField('Connection Status', value=connection_status)

    '''
    page_1.tab_2 = vkt.Tab('Section Data')
    page_1.tab_2.data_btn = vkt.SetParamsButton('Get Midas data', method='populate_section_table')
    page_1.tab_2.table_1 = vkt.Table('Section Properties')
    page_1.tab_2.table_1.section_ID = vkt.TextField('Section ID')
    page_1.tab_2.table_1.section_name = vkt.TextField('Section Name')
    '''
    page_2 = vkt.Page('Chart', views=['get_chart_view','group_nodes_table_view', 'group_elems_table_view'])
    page_2.tab_3 = vkt.Tab('Chart')
    #page_2.tab_3.data_btn = vkt.SetParamsButton('Get Midas data', method='get_data_for_chart')
    page_2.tab_3.group_option = vkt.OptionField('Select a Group', options=get_group_list, flex=100)
    page_2.tab_3.lb1 = vkt.LineBreak()
    page_2.tab_3.static_lc_option = vkt.OptionField('Select a load case', options=get_static_lc_list, 
                                                    visible=chart_field, flex=100, default=0)
    page_2.tab_3.lb2 = vkt.LineBreak()
    page_2.tab_3.design_action = vkt.OptionField('Select a Design Action', options=['Ax',
                                                                                    'Vy',
                                                                                    'Vz',
                                                                                    'Mx',
                                                                                    'My',
                                                                                    'Mz'], default='My', flex=100)
    page_2.tab_3.lb3 = vkt.LineBreak()
    page_2.tab_3.node_display_options = vkt.MultiSelectField('Display Options', options=['Node Numbers',
                                                                                    'Node Markers'],
                                                                                    default=[],
                                                                                    visible=chart_field, flex=100)
    page_2.tab_3.lb4 = vkt.LineBreak()
    page_2.tab_3.test_btn = vkt.SetParamsButton('Testing', method='test_data_transfer', flex=100)

    # Hidden data storage fields
    page_2.tab_3.hidden_group_options_list = vkt.HiddenField('hidden_group_options_list')
    page_2.tab_3.node_data = vkt.HiddenField('Hidden parameter to hold node data')
    page_2.tab_3.element_data = vkt.HiddenField('Hidden parameter to hold element data')
    page_2.tab_3.group_data = vkt.HiddenField('Hidden parameter to hold group data')
    page_2.tab_3.sect_data = vkt.HiddenField('Hidden parameter to hold section data')
    page_2.tab_3.unit_data = vkt.HiddenField('Hidden parameter to hold unit data')
    page_2.tab_3.matl_data = vkt.HiddenField('Hidden parameter to hold material data')
    page_2.tab_3.static_lc_data = vkt.HiddenField('Hidden parameter to hold static load case data')
    page_2.tab_3.default_static_lc = vkt.HiddenField('Hidden parameter to hold static load case data')
    page_2.tab_3.design_action_data = vkt.HiddenField('Hidden parameter to hold static load case data')
    page_2.tab_3.chart_field_visibility = vkt.HiddenField('Hidden parameter to show or hide fields for the chart')
    #_lc_default = page_2.tab_3.static_lc_data[0]
    
    
    page_data_from_midas = vkt.Page('Data From Midas')
    page_data_from_midas.tab_2 = vkt.Tab('Section Data')
    #page_3.tab_2.data_btn = vkt.SetParamsButton('Get Midas data', method='populate_section_table')
    page_data_from_midas.tab_2.data_btn2 = vkt.SetParamsButton('Push section data', method='push_sec_table')
    page_data_from_midas.tab_2.act_units1 = vkt.OutputField('Active Units', value=act_units)
    page_data_from_midas.tab_2.table_1 = vkt.Table('Section Properties')
    page_data_from_midas.tab_2.table_1.section_ID = vkt.TextField('Section ID')
    page_data_from_midas.tab_2.table_1.section_name = vkt.TextField('Section Name')
    #tab_2.table_1.section_type = vkt.TextField('Section Type')

    #Slab parameters
    page_data_from_midas.tab_2.table_1.section_slab_w = vkt.TextField('Slab Width')
    page_data_from_midas.tab_2.table_1.section_slab_t = vkt.TextField('Slab Thickness')
    page_data_from_midas.tab_2.table_1.section_slab_hh = vkt.TextField('Slab Hh')

    #Steel Parameters
    page_data_from_midas.tab_2.table_1.section_steel_B1 = vkt.TextField('B1')
    page_data_from_midas.tab_2.table_1.section_steel_B2 = vkt.TextField('B2')
    page_data_from_midas.tab_2.table_1.section_steel_B3 = vkt.TextField('B3')
    page_data_from_midas.tab_2.table_1.section_steel_B4 = vkt.TextField('B4')
    page_data_from_midas.tab_2.table_1.section_steel_B5 = vkt.TextField('B5')
    page_data_from_midas.tab_2.table_1.section_steel_B6 = vkt.TextField('B6')

    page_data_from_midas.tab_2.table_1.section_steel_H = vkt.TextField('H')
    page_data_from_midas.tab_2.table_1.section_steel_t1 = vkt.TextField('t1')
    page_data_from_midas.tab_2.table_1.section_steel_t2 = vkt.TextField('t2')
    page_data_from_midas.tab_2.table_1.section_steel_tw1 = vkt.TextField('tw1')
    page_data_from_midas.tab_2.table_1.section_steel_tw2 = vkt.TextField('tw2')
    page_data_from_midas.tab_2.table_1.section_steel_bf1 = vkt.TextField('bf1')
    page_data_from_midas.tab_2.table_1.section_steel_bf2 = vkt.TextField('bf2')
    page_data_from_midas.tab_2.table_1.section_steel_tfp = vkt.TextField('tfp')
    
    # Add a tab and table for the material properties in Midas
    page_data_from_midas.tab_3 = vkt.Tab('Material Data')
    page_data_from_midas.tab_3.data_btn2 = vkt.SetParamsButton('Push material data', method='push_mat_table')
    page_data_from_midas.tab_3.act_units1 = vkt.OutputField('Active Units', value=act_units)
    page_data_from_midas.tab_3.table_1 = vkt.Table('Material Properties')
    page_data_from_midas.tab_3.table_1.matl_ID = vkt.TextField('ID')
    page_data_from_midas.tab_3.table_1.matl_type = vkt.TextField('Type')
    page_data_from_midas.tab_3.table_1.matl_name = vkt.TextField('Name')
    page_data_from_midas.tab_3.table_1.matl_E = vkt.TextField('Modulus of elasticity')
    page_data_from_midas.tab_3.table_1.matl_pois = vkt.TextField('Poison Ratio')

    # Add another input table for the design material data of each section
    page_data_from_midas.tab_3.table_2 = vkt.Table('Section Design Material Properties')
    page_data_from_midas.tab_3.table_2.section_ID = vkt.TextField('Section ID')
    page_data_from_midas.tab_3.table_2.section_name = vkt.TextField('Section Name')
    page_data_from_midas.tab_3.table_2.tf_fy = vkt.TextField('Top Flange fy', suffix='MPa')
    
    _weld_options=['SR','HR','LW, CF','HW']
    
    page_data_from_midas.tab_3.table_2.tf_weld = vkt.OptionField('Top Flange Residual Stress State',
                                                                 options=_weld_options) 
    page_data_from_midas.tab_3.table_2.bf_fy = vkt.TextField('Bottom Flange fy', suffix='MPa')
    page_data_from_midas.tab_3.table_2.bf_weld = vkt.OptionField('Bottom Flange Residual Stress State', 
                                                   options=_weld_options)
    page_data_from_midas.tab_3.table_2.web_fy = vkt.TextField('Web fy', suffix='MPa')
    page_data_from_midas.tab_3.table_2.web_weld = vkt.OptionField('Web Residual Stress State', 
                                                   options=_weld_options)
    page_data_from_midas.tab_3.table_2._header_style = "font-weight: bold; text-align: center; background-color: lightgray;"

    # Add another input table for the deck reinforcement
    page_data_from_midas.tab_3.tbl_reo = vkt.Table('Section Deck Reinforcement')
    page_data_from_midas.tab_3.tbl_reo.section_ID = vkt.TextField('Section ID')
    page_data_from_midas.tab_3.tbl_reo.section_name = vkt.TextField('Section Name')
    
    _reo_options = ['NIL','N12','N16','N20','N24','N28','N32','N36']
    
    page_data_from_midas.tab_3.tbl_reo.deck_top_reo_name = vkt.OptionField('Top Reo Type',
                                                                           options=_reo_options)# need a function for this as per the other application
    page_data_from_midas.tab_3.tbl_reo.deck_top_reo_s = vkt.TextField('Top Reo Spacing', suffix='mm')
    page_data_from_midas.tab_3.tbl_reo.deck_top_reo_depth = vkt.TextField('Top Reo Depth', suffix='mm')
    page_data_from_midas.tab_3.tbl_reo.deck_bot_reo_name = vkt.OptionField('Bottom Reo Type',
                                                                           options=_reo_options)# need a function for this as per the other application
    page_data_from_midas.tab_3.tbl_reo.deck_bot_reo_s = vkt.TextField('Bottom Reo Spacing', suffix='mm')
    page_data_from_midas.tab_3.tbl_reo.deck_bot_reo_depth = vkt.TextField('Bottom Reo Depth', suffix='mm')
    
    
    
    
    
    page_design = vkt.Page('Section Design', views=['view_section_design'])
    page_design.section = vkt.OptionField('Select a section to review', options=get_section_ID_list)
    page_design.C_or_NC = vkt.OptionField('Select a section to review', options=['Non composite', 'Composite'])
    page_design.sag_or_hog = vkt.OptionField('Select a section to review', options=['Sagging', 'Hogging'])


class Controller(vkt.Controller):
    parametrization = Parametrization(width=20)

    @vkt.GeometryAndDataView('view_section_design', duration_guess=1, view_mode = '2D')
    def view_section_design(self, params, **kwargs):

        output, data_output, diag_labels = self.calculate_girder_results(params, self.create_design_sections(params))

        return vkt.GeometryAndDataResult(output, data_output, diag_labels)

    """ Shouldn't  need these
    @vkt.GeometryAndDataView('Non-composite Sagging', duration_guess=1, view_mode = '2D')
    def non_composite_sagging(self, params, **kwargs):

        output, data_output, diag_labels = self.calculate_girder_results(params, girder_type="NC", sag_or_hog='sag')

        return vkt.GeometryAndDataResult(output, data_output, diag_labels)

    @vkt.GeometryAndDataView('Non-composite Hogging', duration_guess=1, view_mode = '2D')
    def non_composite_hogging(self, params, **kwargs):

        output, data_output, diag_labels = self.calculate_girder_results(params, girder_type="NC", sag_or_hog='hog')

        return vkt.GeometryAndDataResult(output, data_output, diag_labels)

    @vkt.GeometryAndDataView('Composite Sagging', duration_guess=1, view_mode='2D')
    def composite_sagging(self, params, **kwargs):

        output, data_output, diag_labels = self.calculate_girder_results(params, girder_type="C", sag_or_hog='sag')

        return vkt.GeometryAndDataResult(output, data_output, diag_labels)

    @vkt.GeometryAndDataView('Composite Hogging', duration_guess=1, view_mode='2D')
    def composite_hogging(self, params, **kwargs):

        output, data_output, diag_labels = self.calculate_girder_results(params, girder_type="C", sag_or_hog='hog')

        return vkt.GeometryAndDataResult(output, data_output, diag_labels)
    """

    def connect_API(self, params, **kwargs):
        global midas_obj
        #print(params.page_1.tab_1.section_2.base_url, params.page_1.tab_1.section_2.mapi_key)
        midas_obj = MidasAPIClass(params.page_1.tab_1.section_2.base_url, params.page_1.tab_1.section_2.mapi_key)
        node_data, _ = midas_obj.MidasAPI('GET', '/db/NODE', {})
        elem_data, _ = midas_obj.MidasAPI('GET', '/db/ELEM', {})
        group_data, _ = midas_obj.MidasAPI('GET', '/db/GRUP', {})
        sect_data, _ = midas_obj.MidasAPI('GET', '/db/SECT', {})
        matl_data, _ = midas_obj.MidasAPI('GET', '/db/matl', {})
        current_units = midas_obj.MidasAPI('GET', '/db/unit', {})
        static_lc_data, midas_status = midas_obj.MidasAPI('GET', '/db/STLD', {})
        comb_lc_data, _ = midas_obj.MidasAPI('GET', '/db/LCOM-GEN', {})
        #pprint(comb_lc_data)
        #print(f'{matl_data} \n')
        
        #midas_obj = MidasAPIClass(params.tab_1.section_2.base_url, params.tab_1.section_2.mapi_key)
        response, midas_status = midas_obj.MidasAPI('GET', '/db/PJCF', {})
        #print((response, midas_status))
        if midas_status == 200:
            params.page_2.tab_3.node_data = node_data
            params.page_2.tab_3.element_data = elem_data
            params.page_2.tab_3.group_data = group_data
            params.page_2.tab_3.sect_data = sect_data
            params.page_2.tab_3.unit_data = current_units
            params.page_2.tab_3.matl_data = matl_data
            params.page_1.tab_1.section_1.conn_status = 'Connected'
            #params.page_2.tab_3.static_lc_data = extract_keys_at_level(static_lc_data, 2, 'NAME', current_level=1)
            params.page_2.tab_3.static_lc_data = extract_keys_at_level(comb_lc_data, 2, 'NAME', current_level=1)
            
            params.page_2.tab_3.default_static_lc = params.page_2.tab_3.static_lc_data[0]
            
            #pprint(params.page_2.tab_3.matl_data)         
            params.page_2.tab_3.hidden_group_options_list = extract_keys_at_level(group_data, 2, 'NAME', current_level=1)
            
            self.populate_section_table(params, **kwargs)
            self.populate_material_table(params, **kwargs)
            self.populate_section_material_table(params, **kwargs)
            self.populate_section_deck_reo_table(params, **kwargs)

            design_sections = self.create_design_sections(params)
            
            return vkt.SetParamsResult(params)
        else:
            params.page_1.tab_1.section_1.conn_status = 'Not Connected'
            params.page_2.tab_3.hidden_group_options_list = [' ']
            params.page_2.tab_3.group_option = None
            return vkt.SetParamsResult(params)

    '''def get_all_keys(d):
        for key, value in d.items():
            yield key
            if isinstance(value, dict):
                yield from get_all_keys(value)
    '''
    def populate_section_deck_reo_table(self, params, **kwargs):
        # TODO extract the data for the table
        sect_data = params.page_2.tab_3.sect_data
        table_list = []
        for k, v in sect_data["SECT"].items():
            if v["SECT_BEFORE"]['SHAPE'] == 'GT' and v["SECT_BEFORE"]['SECT_I']['USE_SYM_CALC'] == False: # wrap for unsymmetric section
                table_list.append({"section_ID": k,
                                   "section_name": v["SECT_NAME"],
                                   "deck_top_reo_name": "N32",
                                   "deck_top_reo_s": "200mm",
                                   "deck_top_reo_depth": "100mm",
                                   "deck_bot_reo_name": "N32",
                                   "deck_bot_reo_s": "200mm",
                                   "deck_bot_reo_depth": "240mm"
                                   })
            else:
                continue
        params.page_data_from_midas.tab_3.tbl_reo = table_list
        return vkt.SetParamsResult(params)

    def populate_material_table(self, params, **kwargs):
        # TODO extract the data for the table
        matl_data = params.page_2.tab_3.matl_data
        matl_list = []
        for k, v in matl_data["MATL"].items():
            #print(v["PARAM"][0])
            if v["PARAM"][0]["P_TYPE"] == 2:
                matl_list.append({"matl_ID": k,
                                "matl_type": v["TYPE"],
                                "matl_name": v["NAME"],
                                "matl_E": f'{(v["PARAM"][0]["ELAST"]):.3e}',
                                "matl_pois": f'{v["PARAM"][0]["POISN"]:.2f}'})
            elif v["PARAM"][0]["P_TYPE"] == 1:
                matl_list.append({"matl_ID": k,
                                "matl_type": v["TYPE"],
                                "matl_name": v["NAME"],
                                "matl_E": "As per AS5100",
                                "matl_pois": "As per AS5100"})


        params.page_data_from_midas.tab_3.table_1 = matl_list
        return vkt.SetParamsResult(params)
    
    def populate_section_material_table(self, params, **kwargs):
        sect_data = params.page_2.tab_3.sect_data
        table_list = []
        for k, v in sect_data["SECT"].items():
            if v["SECT_BEFORE"]['SHAPE'] == 'GT' and v["SECT_BEFORE"]['SECT_I']['USE_SYM_CALC'] == False: # wrap for unsymmetric section
                table_list.append({"section_ID": k,
                                   "section_name": v["SECT_NAME"],
                                   "tf_fy": "350MPa",
                                   "bf_fy": "350MPa",
                                   "web_fy": "350MPa",
                                   "bf_weld": "HW",
                                   "tf_weld": "HW",
                                   "web_weld": "HW"
                                   })
            else:
                continue
        params.page_data_from_midas.tab_3.table_2 = table_list
        return vkt.SetParamsResult(params)

    def populate_section_table(self, params, **kwargs):
        #midas_obj = MidasAPIClass(params.page_1.tab_1.section_2.base_url, params.page_1.tab_1.section_2.mapi_key)
        #sect_data = midas_obj.MidasAPI('GET', "/db/SECT", {})
        
        #print(f"Directly loaded: {sect_data[0]}\n")
        
        sect_data = params.page_2.tab_3.sect_data

        #print(f"From params: {sect_data}\n")

        # dat - I've changed sect_data[0] to sect_data in the loop below after saving the section data into
        #  a hidden parameter when Midas is connected.

        table_list = []

        for k, v in sect_data["SECT"].items():
            if v["SECT_BEFORE"]['SHAPE'] == 'GT' and v["SECT_BEFORE"]['SECT_I']['USE_SYM_CALC'] == False: # wrap for unsymmetric section
                table_list.append({"section_ID": k,
                                   "section_name": v["SECT_NAME"],
                                   #"section_type": v["SECTTYPE"],

                                   # Slab Parameters
                                   "section_slab_w": f'{(sect_data["SECT"][str(k)]["SECT_AFTER"]["SLAB"][0]):.3f}',
                                   "section_slab_t": f'{(sect_data["SECT"][str(k)]["SECT_AFTER"]["SLAB"][1]):.3f}',
                                   "section_slab_hh": f'{(sect_data["SECT"][str(k)]["SECT_AFTER"]["SLAB"][2]):.3f}',
                                   # Steel Parameters
                                   "section_steel_B1": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][0]):.3f}',
                                   "section_steel_B2": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][1]):.3f}',
                                   "section_steel_B3": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][2]):.3f}',  #Not required for symmetric sec
                                   "section_steel_B4": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][3]):.3f}',
                                   "section_steel_B5": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][4]):.3f}',
                                   "section_steel_B6": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][5]):.3f}', #Not required for symmetric sec
                                   "section_steel_H": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][6]):.3f}',
                                   "section_steel_t1": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][7]):.3f}',
                                   "section_steel_t2": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][8]):.3f}',
                                   "section_steel_tw1": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][9]):.3f}',
                                   "section_steel_tw2": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][10]):.3f}',  #Not required for symmetric sec
                                   "section_steel_bf1": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][11]):.3f}',
                                   "section_steel_bf2": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][12]):.3f}',  #Not required for symmetric sec
                                   "section_steel_tfp": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][13]):.3f}',
                                   })
            elif v["SECT_BEFORE"]['SHAPE'] == 'GT' and v["SECT_BEFORE"]['SECT_I']['USE_SYM_CALC'] == True: # wrap for symmetric section
                table_list.append({"section_ID": k,
                                   "section_name": v["SECT_NAME"],
                                   #"section_type": v["SECTTYPE"],

                                   # Slab Parameters
                                   "section_slab_w": f'{(sect_data["SECT"][str(k)]["SECT_AFTER"]["SLAB"][0]):.3f}',
                                   "section_slab_t": f'{(sect_data["SECT"][str(k)]["SECT_AFTER"]["SLAB"][1]):.3f}',
                                   "section_slab_hh": f'{(sect_data["SECT"][str(k)]["SECT_AFTER"]["SLAB"][2]):.3f}',
                                   # Steel Parameters
                                   "section_steel_B1": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][0]):.3f}',
                                   "section_steel_B2": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][1]):.3f}',
                                   "section_steel_B3": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][0]):.3f}',  #same as B1
                                   "section_steel_B4": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][3]):.3f}',
                                   "section_steel_B5": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][4]):.3f}',
                                   "section_steel_B6": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][3]):.3f}', #same as B4
                                   "section_steel_H": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][6]):.3f}',
                                   "section_steel_t1": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][7]):.3f}',
                                   "section_steel_t2": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][8]):.3f}',
                                   "section_steel_tw1": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][9]):.3f}',
                                   "section_steel_tw2": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][9]):.3f}',  #same as tw1
                                   "section_steel_bf1": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][11]):.3f}',
                                   "section_steel_bf2": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][11]):.3f}',  #same as bf1
                                   "section_steel_tfp": f'{(sect_data["SECT"][str(k)]["SECT_BEFORE"]["SECT_I"]["vSIZE"][13]):.3f}',
                                   })
            # elif v["SECT_BEFORE"]['SHAPE'] == 'Tub':

            else:
                continue

        # print(sect_data[0]["SECT"][str(k)]["SECT_AFTER"]['SLAB'][0])
        # elif v["SECT_BEFORE"]['SHAPE'] == 'Tub':
        #pprint(table_list)
        params.page_data_from_midas.tab_2.table_1 = table_list
        return vkt.SetParamsResult(params)

    def get_data_for_chart(self, params, **kwargs):
        violations=[]
        lc_list = params.page_2.tab_3.static_lc_data
        lc_option = params.page_2.tab_3.static_lc_option
        #print(params.page_2.tab_3.static_lc_option)
        try:
            subject_lc = lc_list[lc_option].split(': ')[1]
            #subject_lc = params.page_2.tab_3.static_lc_option.split(': ')[1]
            #print(subject_lc)
        except:
            violations.append(vkt.InputViolation("not working", fields=['load case']))
            raise vkt.UserError("Option selection required", input_violations=violations)
        
        subject_group = params.page_2.tab_3.group_option.split(': ')[1]
        midas_obj = MidasAPIClass(params.page_1.tab_1.section_2.base_url, params.page_1.tab_1.section_2.mapi_key)
        design_action_data, midas_status = midas_obj.MidasAPI('POST', "/post/TABLE", get_design_actions(subject_lc,
                                                                                                        subject_group))
        if midas_status == 200:
           params.page_2.tab_3.design_action_data = design_action_data
           #print(params.page_2.tab_3.design_action_data)
        else:
            raise vkt.UserError('Check Midas connection and that the analysis has been completed') 
        return vkt.SetParamsResult(params)
    
    def test_data_transfer(self, params, **kwargs):
        #print(params.page_2.tab_3.group_data)
        return vkt.SetParamsResult(params)
         
    @vkt.TableView("Group Nodes")
    def group_nodes_table_view(self, params, **kwargs):
        # Convert the data object to a list of dictionaries
        subject_group = params.page_2.tab_3.group_option.split(':')[0]
        group_nodes = params.page_2.tab_3.group_data.GRUP[subject_group].N_LIST
        #print(group_nodes)
        #print(params.page_2.tab_3.node_data)

        # Create a reduced list where only the nodes that are in nodes_to_keep exist
        reduced_list = []
        for node_id in params.page_2.tab_3.node_data.NODE:
            if int(node_id) in group_nodes:
                coords = params.page_2.tab_3.node_data.NODE[node_id]
                reduced_list.append({
                    "Node ID": node_id,
                    "X": coords.X,
                    "Y": coords.Y,
                    "Z": coords.Z
                })
        #print(reduced_list)
        data = pd.DataFrame(reduced_list)
        
        return vkt.TableResult(data)    
    
    @vkt.TableView("Group Elements")
    def group_elems_table_view(self, params, **kwargs):
        # Hide irrelevant fields
        params.page_2.tab_3.chart_field_visibility = False
        print(params.page_2.tab_3.chart_field_visibility)
        vkt.SetParamsResult(params.page_2.tab_3.chart_field_visibility)
        # Convert the data object to a list of dictionaries
        subject_group = params.page_2.tab_3.group_option.split(':')[0]
        group_elems = params.page_2.tab_3.group_data.GRUP[subject_group].E_LIST
        #print(group_elems)
        #print(params.page_2.tab_3.element_data)

        # Create a reduced list where only the nodes that are in nodes_to_keep exist
        reduced_list = []
        for elem_id in params.page_2.tab_3.element_data.ELEM:
            if int(elem_id) in group_elems:
                #print(params.page_2.tab_3.element_data.ELEM[elem_id].NODE[0])
                node_i = params.page_2.tab_3.element_data.ELEM[elem_id].NODE[0]
                node_j = params.page_2.tab_3.element_data.ELEM[elem_id].NODE[1]
                section = params.page_2.tab_3.element_data.ELEM[elem_id].SECT
                reduced_list.append({
                    "Element ID": elem_id,
                    "Node i": node_i,
                    "Node j": node_j,
                    "Section Type ID": section
                    })
        #print(reduced_list)
        data = pd.DataFrame(reduced_list)
        return vkt.TableResult(data)
        
    @vkt.PlotlyView('Chart view')
    def get_chart_view(self, params, **kwargs):
        subject_group = params.page_2.tab_3.group_option.split(':')[0]
        group_elems = params.page_2.tab_3.group_data.GRUP[subject_group].E_LIST
        group_nodes = params.page_2.tab_3.group_data.GRUP[subject_group].N_LIST
        elem_data = get_subject_elems(params.page_2.tab_3.element_data, group_elems)
        node_data = get_subject_nodes(params.page_2.tab_3.node_data, group_nodes)
        self.get_data_for_chart(params, **kwargs)
        design_action_data = params.page_2.tab_3.design_action_data
        design_action = params.page_2.tab_3.design_action
        #print(design_action)
        #print(design_action_data)
        
        # Create a graph object to represent the subject data
        g = create_graph(node_data, elem_data, design_action_data)
        # Work out the cumulative node x coordinates (chainages)
        positions = calculate_positions(g)
        # Assign different colours to each section type
        sect_colors = assign_colors(g)
        #print(sect_colors)
        # Plot the line
        node_mode = get_node_mode(params.page_2.tab_3.node_display_options)
        
        fig = plot_graph(g, positions, sect_colors, node_mode, design_action)

        return vkt.PlotlyResult(fig.to_json())
           

    """
    # Get all of the section data
    section_dict = midas_obj.MidasAPI("GET", "/db/SECT", {})
    #print(section_dict)
    output_file = 'section_dump.json'
    with open(output_file, 'w') as f:
        json.dump(section_dict, f, indent=4)
    """

    def push_sec_table(self, params, **kwargs):
        midas_obj = MidasAPIClass(params.page_1.tab_1.section_2.base_url, params.page_1.tab_1.section_2.mapi_key)
        table = params.page_3.tab_2.table_1
        df = pd.DataFrame(table)
        print(df)
        sect_mod_json = {"Assign": {}}
        for sec, row in df.iterrows():
            print(row['section_ID'])
            sect_mod_json["Assign"][row['section_ID']] = {
                    'SECT_NAME': row['section_name']
            }
        pprint(sect_mod_json)
        sect_res = midas_obj.MidasAPI("PUT", "/db/sect", sect_mod_json)

    
    def push_mat_table(self, params, **kwargs):
        pass


    def create_design_sections(self, params):
        """Creates a dictionary of design objects for a Midas cross section """
        design_sections = {}
        for sect_row, mat_row, reo_row in zip(params.page_data_from_midas.tab_2.table_1,
                                              params.page_data_from_midas.tab_3.table_2,
                                              params.page_data_from_midas.tab_3.tbl_reo):

            id = f'{sect_row["section_ID"]}: {sect_row["section_name"]}'
            section_dict = {            
                'NC_sag_girder': self.create_NC_sag_girder(*self.element_creation1(sect_row, mat_row, reo_row)),
                'NC_hog_girder': self.create_NC_hog_girder(*self.element_creation1(sect_row, mat_row, reo_row)),
                'C_sag_girder': self.create_C_sag_girder(*self.element_creation1(sect_row, mat_row, reo_row)),
                'C_hog_girder': self.create_C_hog_girder(*self.element_creation1(sect_row, mat_row, reo_row))
                }
            design_sections[id] = section_dict
        return design_sections

    @staticmethod
    def element_creation1(sect_row, mat_row, reo_row):
        D = ureg(f"{float(sect_row['section_steel_H'])+float(sect_row['section_steel_t2'])+float(sect_row['section_steel_t1'])}m")
        b5 = float(sect_row['section_steel_B5'])
        w_t = (float(sect_row['section_steel_B1'])
                 + float(sect_row['section_steel_B2'])
                 + float(sect_row['section_steel_B3'])
                 -float(sect_row['section_steel_bf1'])
                 -float(sect_row['section_steel_bf2']))
        m = (w_t-b5)/2
        h = float(sect_row['section_steel_H'])
        theta = atan(m/h)
        
        w_top = (w_t+float(sect_row['section_steel_tw1'])/cos(theta)
             +float(sect_row['section_steel_tw2'])/cos(theta))
        top_w = ureg(f"{w_top}m")
        
        w_bot = (b5 + float(sect_row['section_steel_tw1'])/cos(theta)
                 +float(sect_row['section_steel_tw2'])/cos(theta))
        bot_w = ureg(f"{w_bot}m")# Need to read units from Midas file, not hard code
        
        bot_flange_b = ureg(f"{(float(sect_row['section_steel_B5']) + float(sect_row['section_steel_B4']) + float(sect_row['section_steel_B6']))}m")
        bot_flange_t = ureg(f"{sect_row['section_steel_t2']}m")# Need to read units from Midas file, not hard code
        bot_flange_fy = ureg(f"{mat_row['bf_fy']}")# Don't need to add units here as they are set as MPA by default in the table
        bot_flange_resid_stress = f"{mat_row['bf_weld']}"
        
        top_flange_b = ureg(f"{sect_row['section_steel_B1']}m")# Need to read units from Midas file, not hard code
        top_flange_t = ureg(f"{sect_row['section_steel_t1']}m")# Need to read units from Midas file, not hard code
        top_flange_fy = ureg(f"{mat_row['tf_fy']}")
        top_flange_resid_stress = f"{mat_row['tf_weld']}"
        
        
        web_t = ureg(f"{sect_row['section_steel_tw1']}m")# Need to read units from Midas file, not hard code
        web_fy = ureg(f"{mat_row['tf_fy']}")
        web_resid_stress = f"{mat_row['web_weld']}"
        
        deck_D = ureg(f"{sect_row['section_slab_t']}m")# Need to read units from Midas file, not hard code
        deck_w_L = ureg(f"{sect_row['section_slab_w']}m")/2# Need to read units from Midas file, not hard code
        deck_w_R = ureg(f"{sect_row['section_slab_w']}m")/2# Need to read units from Midas file, not hard code
        deck_ef_w_per_flange = ureg(f"{sect_row['section_slab_w']}m")/2# This needs to calculated correctly
        deck_precast_d = ureg('0.0m')# An input variable should be used
        deck_haunch_d = ureg(f"{sect_row['section_slab_hh']}m")
        deck_haunch_w = ureg(f"{sect_row['section_steel_B1']}m")# Set as top flange width but should be independent
        deck_conc_str = ureg('50MPa')# Hard coded.  Need to get from input
        
        deck_top_reo_name = (f"{reo_row['deck_top_reo_name']}")
        deck_top_reo_s = ureg(f"{reo_row['deck_top_reo_s']}")
        deck_top_reo_depth = ureg(f"{reo_row['deck_top_reo_depth']}")
        deck_bot_reo_name = (f"{reo_row['deck_bot_reo_name']}")
        deck_bot_reo_s = ureg(f"{reo_row['deck_bot_reo_s']}")
        deck_bot_reo_depth = ureg(f"{reo_row['deck_bot_reo_depth']}")

        section_geometry = SectionGeometry1(D.to_base_units(),
                                            top_w.to_base_units(),
                                            bot_w.to_base_units()
                                            )
        
        bot_flange_in = Flange1(bot_flange_b.to_base_units(),
                                bot_flange_t.to_base_units(),
                                bot_flange_fy.to('MPa'),
                                bot_flange_resid_stress
                                )
        
        top_flange_in = Flange1(top_flange_b.to_base_units(),
                                top_flange_t.to_base_units(),
                                top_flange_fy.to('MPa'),
                                top_flange_resid_stress
                                )
        
        web_in = Web1(web_t.to_base_units(),
                      web_fy.to('MPa'),
                      web_resid_stress
                      )
        
        deck_in = Deck(deck_w_L.to_base_units(),
                       deck_w_R.to_base_units(),
                       deck_D.to_base_units(),
                       deck_ef_w_per_flange.to_base_units(),
                       deck_conc_str.to('MPa'),
                       deck_precast_d.to_base_units(),
                       deck_haunch_d.to_base_units(),
                       deck_haunch_w.to_base_units()                       
                       )
        
        reo_in = Reinforcement(deck_top_reo_name,
                               deck_top_reo_s.to_base_units(),
                               deck_top_reo_depth.to_base_units(),
                               deck_bot_reo_name,
                               deck_bot_reo_s.to_base_units(),
                               deck_bot_reo_depth.to_base_units())
        
        return section_geometry, bot_flange_in, top_flange_in, web_in, deck_in, reo_in

    def calculate_girder_results(self, params: Munch, design_sections):
        """Calculates the girder results, with a 2D geometry as a visual representation of the result,
        as well as a DataGroup with a summary of the calculated results.

        :param params: The input from the VIKTOR parametrization
        :param girder_type: "NC" for Non-composite girder, "C" for Composite girder
        :param sag_or_hog: "sag" if sagging is calculated, "hog" for hogging.
        :return:
        """
        #pprint((design_sections))
        match params.page_design.sag_or_hog:
            case 'Sagging':
                side = "Top"
                side_variable = "tf"
                #print(params.page_design.sag_or_hog, params.page_design.C_or_NC)
                match params.page_design.C_or_NC:
                    case 'Non composite':
                        new_steel_section = design_sections[params.page_design.section]['NC_sag_girder']
                    case 'Composite':
                        new_steel_section = design_sections[params.page_design.section]['C_sag_girder']
            case 'Hogging':
                side = "Bottom"
                side_variable = 'bf'
                #print(params.page_design.sag_or_hog, params.page_design.C_or_NC)
                match params.page_design.C_or_NC:
                    case 'Non composite':
                        new_steel_section = design_sections[params.page_design.section]['NC_hog_girder']
                    case 'Composite':
                        new_steel_section = design_sections[params.page_design.section]['C_hog_girder']
       
        data_output = vkt.DataGroup(
            group_capacity=vkt.DataItem('Capacities','',subgroup=vkt.DataGroup(
                vkt.DataItem(f'Bending $\\phi M_{{sx}}$', f"{getattr(new_steel_section, f'phiMsx').to('knewton*m'):.0f~P}")
            )),
            group_slenderness=vkt.DataItem('Section Slenderness','',subgroup=vkt.DataGroup(
                vkt.DataItem('Status', f"{getattr(new_steel_section, f'ef_status')}"),
                vkt.DataItem(f'{side} flange slenderness $\\lambda_{{e}}$', f"{getattr(new_steel_section, f'{side_variable}_slenderness').element_slenderness():.2f~P}"),
                vkt.DataItem(f'{side} flange slenderness ratio $\\lambda_{{e}}$/$\\lambda_{{ey}}$', f"{getattr(new_steel_section, f'{side_variable}_slenderness').slenderness_ratio():.2f~P}"),
                vkt.DataItem('Web slenderness $\\lambda_{e}$', f"{getattr(new_steel_section, f'web_slenderness').element_slenderness().m:.2f}"),
                vkt.DataItem('Web slenderness ratio $\\lambda_{{e}}$/$\\lambda_{{ey}}$', f"{getattr(new_steel_section, f'web_slenderness').slenderness_ratio():.2f~P}"),
                vkt.DataItem('Section slenderness $\\lambda_{{s}}$', f"{getattr(new_steel_section, f'ls'):.2f~P}"),
                vkt.DataItem('Section plasticity limit $\\lambda_{{sp}}$', f"{getattr(new_steel_section, f'lsp'):.2f}"),
                vkt.DataItem('Section yield limit $\\lambda_{{sy}}$', f"{getattr(new_steel_section, f'lsy'):.2f}")
            )),
            group_gross=vkt.DataItem('Gross Section Properties','',subgroup=vkt.DataGroup(
                vkt.DataItem('Area $A_{g}$', f"{getattr(new_steel_section, 'A_g').to('mm**2'):.0f~P}"),
                vkt.DataItem('NA depth', f"{getattr(new_steel_section, 'dNA_g').to('mm'):.0f~}"),
                vkt.DataItem('$I_{x}$', f"{getattr(new_steel_section, 'Ix_g').to('mm**4'):.0f~P}"),
                vkt.DataItem('$Z_{x,top}$', f"{getattr(new_steel_section, 'Zx_top_g').to('mm**3'):.0f~P}"),
                vkt.DataItem('$Z_{x,bot}$', f"{getattr(new_steel_section, 'Zx_bot_g').to('mm**3'):.0f~P}"),
                vkt.DataItem('Equal area axis depth', f"{getattr(new_steel_section, 'dEAA_g').to('mm'):.0f~}"),
                vkt.DataItem('$S_{x}$', f"{getattr(new_steel_section, f'section_props_g').sx.to('mm**3'):.0f~P}")
            )),
            group_effective=vkt.DataItem('Effective Section Properties','',subgroup=vkt.DataGroup(
                vkt.DataItem('Area $A_{ef}$', f"{getattr(new_steel_section, 'Aef').to('mm**2'):.0f~P}"),
                # These all point to effective section properties
                vkt.DataItem('NA depth', f"{getattr(new_steel_section, 'dNA_ef').to('mm'):.0f~}"),
                vkt.DataItem('$I_{x}$', f"{getattr(new_steel_section, 'Ix_ef').to('mm**4'):.0f~P}"),
                vkt.DataItem('$Z_{x,top}$', f"{getattr(new_steel_section, 'Zx_top_ef').to('mm**3'):.0f~P}"),
                vkt.DataItem('$Z_{x,bot}$', f"{getattr(new_steel_section, 'Zx_bot_ef').to('mm**3'):.0f~P}"),
                vkt.DataItem('Equal area axis depth', f"{getattr(new_steel_section, 'dEAA_ef').to('mm'):.0f~}"),
                vkt.DataItem('$S_{x}$', f"{getattr(new_steel_section, f'section_props_ef').sx.to('mm**3'):.0f~P}")
            )),
        )


        el_display = getattr(new_steel_section, f'gross_elements') + getattr(new_steel_section, f'ef_el')
        
        if params.page_design.C_or_NC == 'Composite':
            el_display = el_display + (getattr(new_steel_section, f'deck_shapes'))
        
        # Axis lines and labels#
        axes, labels = self.draw_axes(new_steel_section)
        el_display += axes
        elements = vkt.Group(el_display)
        
        return elements, data_output, labels

    @staticmethod
    def create_NC_sag_girder(*args) -> tg_NC_sag:
        #section_geometry, bot_flange_in, top_flange_in, web_in, deck_in, reo_in = element_creation1(*args)
        new_steel_section = tg_NC_sag(args[0], args[3], args[2], args[1])
        return new_steel_section
    
    @staticmethod
    def create_NC_hog_girder(*args) -> tg_NC_hog:
        #section_geometry, bot_flange_in, top_flange_in, web_in, deck_in, reo_in = element_creation1(*args)
        new_steel_section = tg_NC_hog(args[0], args[3], args[2], args[1])
        return new_steel_section

    @staticmethod
    def create_C_sag_girder(*args) -> tg_C_sag:
        #section_geometry, bot_flange_in, top_flange_in, web_in, deck_in, reo_in = element_creation1(*args)
        new_steel_section = tg_C_sag(args[0], args[3], args[2], args[1], args[4])
        return new_steel_section
    
    @staticmethod
    def create_C_hog_girder(*args) -> tg_C_hog:
        #section_geometry, bot_flange_in, top_flange_in, web_in, deck_in, reo_in = element_creation1(*args)
        new_steel_section = tg_C_hog(args[0], args[3], args[2], args[1], args[4], args[5])
        return new_steel_section

    @staticmethod
    def draw_axes(new_steel_section):
        vert_axis = vkt.Line(vkt.Point(0, 0.3), vkt.Point(0, -(new_steel_section.geometry.D.m + 0.3)), color=vkt.Color.black())
        horiz_axis_elastic = vkt.Line(vkt.Point(-(new_steel_section.geometry.w_top.m / 2),
                                        -new_steel_section.dNA_g.m),
                                  vkt.Point((new_steel_section.geometry.w_top.m / 2),
                                        -new_steel_section.dNA_g.m), color=vkt.Color.black())
        x_l = vkt.Label(vkt.Point(-1.05 * (new_steel_section.geometry.w_top.m / 2),
                          -new_steel_section.dNA_g.m), 'X', size_factor=1.1, color=vkt.Color.black())
        x_r = vkt.Label(vkt.Point(1.05 * (new_steel_section.geometry.w_top.m / 2),
                          -new_steel_section.dNA_g.m), 'X', size_factor=1.1, color=vkt.Color.black())
        horiz_axis_plastic = vkt.Line(vkt.Point(-(new_steel_section.geometry.w_top.m / 2),
                                        -new_steel_section.dEAA_ef.m),
                                  vkt.Point((new_steel_section.geometry.w_top.m / 2),
                                        -new_steel_section.dEAA_ef.m), color=vkt.Color.red())
        plastic_NA = vkt.Label(vkt.Point(0, -new_steel_section.dEAA_ef.m), 'Equal Area Axis', size_factor=1.1, color=vkt.Color.red())

        axes = [vert_axis, horiz_axis_elastic, horiz_axis_plastic]
        labels = [x_l, x_r, plastic_NA]
        return axes, labels
