from trough_girder import TroughGirder1
from data_classes import SectionGeometry1, \
    Web1, Flange1, TopFlange1, BottomFlange1, \
        Web11, Deck, Deck1_sag, Deck1_hog, Reinforcement
from viktor.geometry import Point, Polygon, Vector, \
    Material, Color 
from section_properties import tg_section_props
from element_slenderness import TopFlangeSlenderness, \
    BottomFlangeSlenderness, WebSlenderness, ElementSlenderness
from tg_NC_hog import tg_NC_hog
from concrete_tools import get_Ecj, get_reo_area
from unit_registry import ureg, Q_




class tg_C_hog(TroughGirder1):
    def __init__(self, geometry:SectionGeometry1, \
                 web:Web1, top_flange:Flange1, \
                    bot_flange:Flange1, deck:Deck, reo:Reinforcement) -> None:

        super().__init__(geometry, web, top_flange, \
                    bot_flange)
        
        # Create the deck element and add it to the gross elements
        self.deck = Deck1_hog(geometry, deck, reo)
        self.gross_elements.extend(self.deck.ef_deck_shapes)

        self.deck_shapes = self.deck.deck_gross_shapes
        
        # Set the gross element properties
        self.gross_section_props(self.gross_elements)

        # Create the web slenderness object
        self.web_slenderness = self.calc_web_slenderness(self.web_L.b,
                                        web.t,
                                        web.yield_strength,
                                        (geometry.D-top_flange.t-bot_flange.t),
                                        self.dNA_g-top_flange.t,
                                        self.dEAA_g-top_flange.t)
        
        # Calculate the section slenderness parameters
        self.ls, self.lsy, self.lsp = \
            self.section_slenderness([self.bf_slenderness,
                                       self.web_slenderness])
        
        # Calculate the effective section properties
        self.calc_ef_properties(self.web_slenderness,
                                self.dNA_g,
                                self.ls,
                                self.lsy,
                                self.lsp,
                                'H')


    def calc_ef_properties(self, web_slenderness, dNA_g, ls, lsy, lsp, S_or_H):
        # print('In tg_C_sag calc_properties with C_dNA_g of:', dNA_g)
        super().calc_ef_properties(web_slenderness, dNA_g, ls, lsy, lsp, S_or_H)
        
        if ls < lsp:
            self.ef_el.extend(self.deck.ef_deck_shapes)
            self.section_props_ef = tg_section_props(self.ef_el)
            self.Zxef = self.section_props_ef.Zex
        elif self.ls < self.lsy:
            self.ef_el.extend(self.deck.ef_deck_shapes)
            self.section_props_ef = tg_section_props(self.ef_el)
            self.Zxef = self.section_props_ef.Zx
        else:
            self.ef_el[3] = self.eff_web(web_slenderness,self.web_L,'hog',dNA_g)[0]
            self.ef_el[4] = self.eff_web(web_slenderness,self.web_L,'hog',dNA_g)[1]
            self.ef_el[5] = self.eff_web(web_slenderness,self.web_R,'hog',dNA_g)[0]
            self.ef_el[6] = self.eff_web(web_slenderness,self.web_R,'hog',dNA_g)[1]
            self.ef_el.extend(self.deck.ef_deck_shapes)
            self.section_props_ef = tg_section_props(self.ef_el)
            self.Zxef = self.section_props_ef.Zex
        
        self.phiMsx = 0.9*self.Zxef*self.fy
        self.Aef = self.section_props_ef.A*ureg('m**2')
        self.dNA_ef = self.section_props_ef.dNA*ureg('m')
        self.Ix_ef = self.section_props_ef.Ix*ureg('m**4')
        self.dEAA_ef = self.section_props_ef.dEAA*ureg('m')
        self.Zx_top_ef = self.section_props_ef.Zx_top*ureg('m**3')
        self.Zx_bot_ef = self.section_props_ef.Zx_bot*ureg('m**3')
        self.dEAA_ef = self.section_props_ef.dEAA*ureg('m')

       