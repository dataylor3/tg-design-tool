from unit_registry import ureg, Q_

class ElementSlenderness():
    def __init__(self, b:Q_, t:Q_, fy:Q_) -> None:
        self.b = b
        self.t = t
        self.fy = fy
    
    def element_slenderness(self):
        self.le = self.b/self.t*(self.fy/(250*ureg.MPa))**0.5
        return self.le
    
    def slenderness_ratio(self) -> float:
        self.le_ratio = self.element_slenderness()/self.ley
        return self.le_ratio
 
    
class TopFlangeSlenderness(ElementSlenderness):
    def __init__(self, b: Q_, t: Q_, fy: Q_, resid_stress: str) -> None:
        super().__init__(b, t, fy)
        self.resid_stress = resid_stress

        match self.resid_stress:
            case 'SR':
                self.lep = 10.0
                self.ley = 16.0
                self.led = 35.0
            case 'HR':
                self.lep = 9.0
                self.ley = 16.0
                self.led = 35.0
            case 'LW, CF':
                self.lep = 8.0
                self.ley = 15.0
                self.led = 35.0
            case 'HW':
                self.lep = 8.0
                self.ley = 14.0
                self.led = 35.0
    

class BottomFlangeSlenderness(ElementSlenderness):
    def __init__(self, b: Q_, t: Q_, fy: Q_, resid_stress: str) -> None:
        super().__init__(b, t, fy)
        self.resid_stress = resid_stress

        match self.resid_stress:
            case 'SR':
                self.lep = 30.0
                self.ley = 45.0
                self.led = 90.0
            case 'HR':
                self.lep = 30.0
                self.ley = 45.0
                self.led = 90.0
            case 'LW, CF':
                self.lep = 30.0
                self.ley = 40.0
                self.led = 90.0
            case 'HW':
                self.lep = 30.0
                self.ley = 35.0
                self.led = 90.0


class WebSlenderness(ElementSlenderness):
    def __init__(self, b:Q_, t:Q_, fy:Q_, d1:Q_, d1NA:Q_, d1EAA:Q_) -> None:
        super().__init__(b, t, fy)
        self.d1 = d1
        self.d1NA = d1NA
        self.d1EAA = d1EAA
        
        self.web_re = ((self.d1NA)/(self.d1)).m
        self.ley = 60/self.web_re

        self.web_rp = ((self.d1EAA)/(self.d1)).m
#        print(self.d1EAA,self.d1,self.web_rp)
        if self.web_rp <= 0:
            self.lep = 9999
        elif self.web_rp < 0.5:
            self.lep = 41/self.web_rp
        else:
            self.lep = 111/(4.7*self.web_rp-1)


