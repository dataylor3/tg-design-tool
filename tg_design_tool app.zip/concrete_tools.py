import numpy as np
import csv
from unit_registry import ureg, Q_
from pathlib import Path

def get_Ecj(fc:Q_)->Q_:
    strength_data = [20,
                     25,
                     32,
                     40,
                     50,
                     65,
                     80,
                     100]
    modulus_data = [24000,
                    26700,
                    30100,
                    32800,
                    34800,
                    37400,
                    39600,
                    42200]
    return np.interp(fc.m, strength_data,
                     modulus_data,
                     left=15000,
                     right=42200)*ureg('MPa')

def get_reo_area(bar_name:str)->Q_:
    fp = Path(__file__).parent / 'reinforcement.csv'
    #file = 'reinforcement.csv'
    with open(fp, 'r') as file:
        reader = csv.DictReader(file)
        for row in reader:
            if row['Name'] == bar_name:
                return ureg(row['Ast'])
            #else:
            #    return 0*ureg('mm**2')
