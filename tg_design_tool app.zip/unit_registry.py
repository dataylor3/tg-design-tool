from pint import UnitRegistry
ureg = UnitRegistry()
Q_ = ureg.Quantity
#ureg.default_format = "~P"
ureg.formatter.default_format = "~P"