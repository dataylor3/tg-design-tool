from trough_girder import TroughGirder1
from data_classes import SectionGeometry1, \
    Web1, Flange1, TopFlange1, BottomFlange1, \
        Web11, Deck1
from viktor.geometry import Point, Polygon, Vector, \
    Material, Color 
from section_properties import tg_section_props
from element_slenderness import TopFlangeSlenderness, BottomFlangeSlenderness, WebSlenderness, ElementSlenderness
from unit_registry import ureg, Q_


class tg_NC_hog(TroughGirder1):
    def __init__(self, geometry:SectionGeometry1, \
                 web:Web1, top_flange:Flange1, \
                    bot_flange:Flange1) -> None:

        super().__init__(geometry, web, top_flange, \
                    bot_flange)

        # Set the gross elelemnt properties
        self.gross_section_props(self.gross_elements)

        # Create the web the web slenderness object
        self.web_slenderness = self.calc_web_slenderness(self.web_L.b,
                                              web.t,
                                              web.yield_strength,
                                              (geometry.D-top_flange.t-bot_flange.t),
                                              self.dNA_g-top_flange.t,
                                              self.dEAA_g-top_flange.t)

        # Calculate the section slenderness parameters
        self.ls, self.lsy, self.lsp = \
            self.section_slenderness([self.bf_slenderness,
                                       self.web_slenderness])

        # Calculate the effective section properties
        self.calc_ef_properties(self.web_slenderness,
                                self.dNA_g,
                                self.ls,
                                self.lsy,
                                self.lsp,
                                'H')

        """
        self.ls, self.lsy, self.lsp = self.section_slenderness([self.bf_slenderness,
                                                                 self.web_slenderness])
        
        if self.ls < self.lsp:
            ef_tf_L = Polygon(self.top_flange_L.shape.points, material=Material(color = Color.blue()))
            ef_tf_R = Polygon(self.top_flange_R.shape.points, material=Material(color = Color.blue()))
            ef_web_L = Polygon(self.web_L.shape.points, material=Material(color = Color.red()))
            ef_web_R = Polygon(self.web_R.shape.points, material=Material(color = Color.red()))
            ef_bf = Polygon(self.bot_flange.shape.points, material=Material(color = Color.green()))
            self.ef_el = [ef_tf_L,ef_tf_R,ef_bf,ef_web_L,ef_web_R]
            self.section_props_ef = tg_section_props(self.ef_el)
            self.ef_status = 'Section is compact'
        else:
            ef_tf_L = Polygon(self.top_flange_L.shape.points, material=Material(color = Color.blue()))
            ef_tf_R = Polygon(self.top_flange_R.shape.points, material=Material(color = Color.blue()))
            ef_web_L = self.eff_web(self.web_slenderness,self.web_L,'hog', self.dNA_g)
            ef_web_R = self.eff_web(self.web_slenderness,self.web_R,'hog', self.dNA_g)
            ef_bf = self.eff_bot_flange(self.bf_slenderness, self.bot_flange)
            self.ef_el = [ef_tf_L,ef_tf_R,ef_bf]+ef_web_L+ef_web_R
            self.section_props_ef = tg_section_props(self.ef_el)
            self.ef_status = 'Section is NOT compact'
        
        self.Zxef = self.section_props_ef.Zex
        self.phiMsx = 0.9*self.Zxef*self.fy

        self.Aef = self.section_props_ef.A*ureg('m**2')
        self.dNA_ef = self.section_props_ef.dNA*ureg('m')
        self.Ix_ef = self.section_props_ef.Ix*ureg('m**4')
        self.dEAA_ef = self.section_props_ef.dEAA*ureg('m')
        self.Zx_top_ef = self.section_props_ef.Zx_top*ureg('m**3')
        self.Zx_bot_ef = self.section_props_ef.Zx_bot*ureg('m**3')
        self.dEAA_ef = self.section_props_ef.dEAA*ureg('m')
        """

