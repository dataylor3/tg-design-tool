from trough_girder import TroughGirder1
from data_classes import SectionGeometry1, \
    Web1, Flange1, TopFlange1, BottomFlange1, \
        Web11, Deck1
from viktor.geometry import Point, Polygon, Vector, \
    Material, Color 
from section_properties import tg_section_props
from element_slenderness import TopFlangeSlenderness, \
    BottomFlangeSlenderness, WebSlenderness, ElementSlenderness
from unit_registry import ureg, Q_



class tg_NC_sag(TroughGirder1):
    def __init__(self, geometry:SectionGeometry1, \
                 web:Web1, top_flange:Flange1, \
                    bot_flange:Flange1) -> None:

        super().__init__(geometry, web, top_flange, \
                    bot_flange)
        
        """
        self.section_props_g = tg_section_props(self.gross_elements)

        self.A_g = self.section_props_g.A*ureg('m**2')
        self.dNA_g = self.section_props_g.dNA*ureg('m')
        self.Ix_g = self.section_props_g.Ix*ureg('m**4')
        self.dEAA_g = self.section_props_g.dEAA*ureg('m')
        self.Zx_top_g = self.section_props_g.Zx_top*ureg('m**3')
        self.Zx_bot_g = self.section_props_g.Zx_bot*ureg('m**3')
        """
        # Set the gross elelemnt properties
        self.gross_section_props(self.gross_elements)

        # Create the web the web slenderness object
        self.web_slenderness = self.calc_web_slenderness(self.web_L.b,
                                              web.t,
                                              web.yield_strength,
                                              (geometry.D-top_flange.t-bot_flange.t),
                                              self.dNA_g-top_flange.t,
                                              self.dEAA_g-top_flange.t)

        # Calculate the section slenderness parameters
        self.ls, self.lsy, self.lsp = \
            self.section_slenderness([self.tf_slenderness,
                                       self.web_slenderness])
        
        # Calculate the effective section properties
        self.calc_ef_properties(self.web_slenderness,
                                self.dNA_g,
                                self.ls,
                                self.lsy,
                                self.lsp,
                                'S')




"""        
        self.phiMsx = 0.9*self.Zxef*self.fy
        self.Aef = self.section_props_ef.A*ureg('m**2')
        self.dNA_ef = self.section_props_ef.dNA*ureg('m')
        self.Ix_ef = self.section_props_ef.Ix*ureg('m**4')
        self.dEAA_ef = self.section_props_ef.dEAA*ureg('m')
        self.Zx_top_ef = self.section_props_ef.Zx_top*ureg('m**3')
        self.Zx_bot_ef = self.section_props_ef.Zx_bot*ureg('m**3')
        self.dEAA_ef = self.section_props_ef.dEAA*ureg('m')

    def calc_properties(self, web_slenderness, dNA_g):   
        print('In tg_NC_sag calc_properties') 
        if self.ls < self.lsp:
            ef_tf_L = Polygon(self.top_flange_L.shape.points, material=Material(color = Color.blue()))
            ef_tf_R = Polygon(self.top_flange_R.shape.points, material=Material(color = Color.blue()))
            ef_web_L = Polygon(self.web_L.shape.points, material=Material(color = Color.red()))
            ef_web_R = Polygon(self.web_R.shape.points, material=Material(color = Color.red()))
            ef_bf = Polygon(self.bot_flange.shape.points, material=Material(color = Color.green()))
            self.ef_el = [ef_tf_L,ef_tf_R,ef_bf,ef_web_L,ef_web_R]
            self.section_props_ef = tg_section_props(self.ef_el)
            self.Zxef = self.section_props_ef.Zex
            self.ef_status = 'Section is compact'
        elif self.ls < self.lsy:
            ef_tf_L = Polygon(self.top_flange_L.shape.points, material=Material(color = Color.blue()))
            ef_tf_R = Polygon(self.top_flange_R.shape.points, material=Material(color = Color.blue()))
            ef_web_L = Polygon(self.web_L.shape.points, material=Material(color = Color.red()))
            ef_web_R = Polygon(self.web_R.shape.points, material=Material(color = Color.red()))
            ef_bf = Polygon(self.bot_flange.shape.points, material=Material(color = Color.green()))
            self.ef_el = [ef_tf_L,ef_tf_R,ef_bf,ef_web_L,ef_web_R]
            self.section_props_ef = tg_section_props(self.ef_el)
            self.Zxef = self.section_props_ef.Zx
            self.ef_status = 'Section is Not compact'
        else:
            ef_tf_L = self.eff_top_flange(self.tf_slenderness,self.top_flange_L)
            ef_tf_R = self.eff_top_flange(self.tf_slenderness,self.top_flange_R)
            ef_web_L = self.eff_web(web_slenderness,self.web_L,'sag',dNA_g)
            ef_web_R = self.eff_web(web_slenderness,self.web_R,'sag',dNA_g)
            ef_bf = Polygon(self.bot_flange.shape.points, material=Material(color = Color.green()))
            self.ef_el = [ef_tf_L,ef_tf_R,ef_bf]+ef_web_L+ef_web_R
            self.section_props_ef = tg_section_props(self.ef_el)
            self.Zxef = self.section_props_ef.Zex
            self.ef_status = 'Section is NOT compact (slender)'
"""