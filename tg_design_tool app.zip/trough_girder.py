from viktor.geometry import Point, Polygon, Vector, Material, Color 

from data_classes import SectionGeometry1, Web1, Flange1, TopFlange1, BottomFlange1, Web11, Deck1
from element_slenderness import TopFlangeSlenderness, BottomFlangeSlenderness, WebSlenderness, ElementSlenderness
from section_properties import tg_section_props

from math import sin, cos, tan
from unit_registry import ureg, Q_

class TroughGirder1():
    def __init__(self, geometry:SectionGeometry1, web:Web1, top_flange:Flange1, bot_flange:Flange1) -> None:
        # print("TroughGirder1__init__")
        self.geometry = geometry
        self.top_flange_L = TopFlange1(self.geometry,top_flange,'L')
        self.top_flange_R = TopFlange1(self.geometry,top_flange,'R')
        self.bot_flange = BottomFlange1(self.geometry, bot_flange)
        self.web_L = Web11(self.geometry,web,self.top_flange_L,self.bot_flange,'L')
        self.web_R = Web11(self.geometry,web,self.top_flange_R,self.bot_flange,'R')
        self.fy = min(web.yield_strength, top_flange.yield_strength, bot_flange.yield_strength)
        self.gross_elements: list[Polygon] = [self.web_R.shape,self.top_flange_L.shape,
                                              self.top_flange_R.shape,
                                              self.web_L.shape,                                              
                                              self.bot_flange.shape                                              
                                              ]

        
       
        self.bf_slenderness = BottomFlangeSlenderness(geometry.w_bot,
                                                   bot_flange.t,
                                                   bot_flange.yield_strength,
                                                   bot_flange.stress_state)
        
        self.tf_slenderness = TopFlangeSlenderness(top_flange.b/2,
                                                   top_flange.t,
                                                   top_flange.yield_strength,
                                                   top_flange.stress_state)
        """
        self.web_slenderness_sag = WebSlenderness(self.web_L.b,
                                              web.t,
                                              web.yield_strength,
                                              (geometry.D-top_flange.t-bot_flange.t),
                                              self.dNA_g-top_flange.t,
                                              self.dEAA_g-top_flange.t)
                                              
        self.web_slenderness_hog = WebSlenderness(self.web_L.b,
                                              web.t,
                                              web.yield_strength,
                                              (geometry.D-top_flange.t-bot_flange.t),
                                              geometry.D-self.dNA_g-bot_flange.t,
                                              geometry.D-self.dEAA_g-bot_flange.t
                                              )

        
#############################################
# Non-composite sagging capacity            #
# Top flange and web subject to compression #
#############################################
        self.ls_sag_ef_NC, self.lsy_sag_ef_NC, self.lsp_sag_ef_NC = self.section_slenderness([self.tf_slenderness,
                                                                 self.web_slenderness_sag])
        
        if self.ls_sag_ef_NC < self.lsp_sag_ef_NC:
            sag_ef_NC_tf_L = Polygon(self.top_flange_L.shape.points, material=Material(color = Color.blue()))
            sag_ef_NC_tf_R = Polygon(self.top_flange_R.shape.points, material=Material(color = Color.blue()))
            sag_ef_NC_web_L = Polygon(self.web_L.shape.points, material=Material(color = Color.red()))
            sag_ef_NC_web_R = Polygon(self.web_R.shape.points, material=Material(color = Color.red()))
            sag_ef_NC_bf = Polygon(self.bot_flange.shape.points, material=Material(color = Color.green()))
            self.sag_ef_NC_el = [sag_ef_NC_tf_L,sag_ef_NC_tf_R,sag_ef_NC_bf,sag_ef_NC_web_L,sag_ef_NC_web_R]
            self.section_props_sag_ef_NC = tg_section_props(self.gross_elements_NC)
            self.sag_ef_NC_status = 'Section is compact'
        else:
            sag_ef_NC_tf_L = self.eff_top_flange(self.tf_slenderness,self.top_flange_L)
            sag_ef_NC_tf_R = self.eff_top_flange(self.tf_slenderness,self.top_flange_R)
            sag_ef_NC_web_L = self.eff_web(self.web_slenderness_sag,self.web_L,'sag')
            sag_ef_NC_web_R = self.eff_web(self.web_slenderness_sag,self.web_R,'sag')
            sag_ef_NC_bf = Polygon(self.bot_flange.shape.points, material=Material(color = Color.green()))
            self.sag_ef_NC_el = [sag_ef_NC_tf_L,sag_ef_NC_tf_R,sag_ef_NC_bf]+sag_ef_NC_web_L+sag_ef_NC_web_R
            self.section_props_sag_ef_NC = tg_section_props(self.sag_ef_NC_el)
            self.sag_ef_NC_status = 'Section is NOT compact'
        
        self.Zxef_sag_NC = self.section_props_sag_ef_NC.Zex
        self.phiMsx_sag_NC = 0.9*self.Zxef_sag_NC*self.fy

#############################################
# Non-composite hogging capacity            #
# Top flange and web subject to compression #
#############################################
        
        self.ls_hog_ef_NC, self.lsy_hog_ef_NC, self.lsp_hog_ef_NC = self.section_slenderness([self.bf_slenderness,
                                                                 self.web_slenderness_hog])
        
        if self.ls_hog_ef_NC < self.lsp_hog_ef_NC:
            hog_ef_NC_tf_L = Polygon(self.top_flange_L.shape.points, material=Material(color = Color.blue()))
            hog_ef_NC_tf_R = Polygon(self.top_flange_R.shape.points, material=Material(color = Color.blue()))
            hog_ef_NC_web_L = Polygon(self.web_L.shape.points, material=Material(color = Color.red()))
            hog_ef_NC_web_R = Polygon(self.web_R.shape.points, material=Material(color = Color.red()))
            hog_ef_NC_bf = Polygon(self.bot_flange.shape.points, material=Material(color = Color.green()))
            self.hog_ef_NC_el = [hog_ef_NC_tf_L,hog_ef_NC_tf_R,hog_ef_NC_bf,hog_ef_NC_web_L,hog_ef_NC_web_R]
            self.section_props_hog_ef_NC = tg_section_props(self.gross_elements_NC)
            self.hog_ef_NC_status = 'Section is compact'
        else:
            hog_ef_NC_tf_L = Polygon(self.top_flange_L.shape.points, material=Material(color = Color.blue()))
            hog_ef_NC_tf_R = Polygon(self.top_flange_R.shape.points, material=Material(color = Color.blue()))
            hog_ef_NC_web_L = self.eff_web(self.web_slenderness_hog,self.web_L,'hog')
            hog_ef_NC_web_R = self.eff_web(self.web_slenderness_hog,self.web_R,'hog')
            hog_ef_NC_bf = self.eff_bot_flange(self.bf_slenderness, self.bot_flange)
            self.hog_ef_NC_el = [hog_ef_NC_tf_L,hog_ef_NC_tf_R,hog_ef_NC_bf]+hog_ef_NC_web_L+hog_ef_NC_web_R
            self.section_props_hog_ef_NC = tg_section_props(self.hog_ef_NC_el)
            self.hog_ef_NC_status = 'Section is NOT compact'
        
        self.Zxef_hog_NC = self.section_props_hog_ef_NC.Zex
        self.phiMsx_hog_NC = 0.9*self.Zxef_hog_NC*self.fy
        """

    def compact_ef_els(self):
        ef_tf_L = Polygon(self.top_flange_L.shape.points, material=Material(color = Color.blue()))
        ef_tf_R = Polygon(self.top_flange_R.shape.points, material=Material(color = Color.blue()))
        ef_web_L = Polygon(self.web_L.shape.points, material=Material(color = Color.red()))
        ef_web_R = Polygon(self.web_R.shape.points, material=Material(color = Color.red()))
        ef_bf = Polygon(self.bot_flange.shape.points, material=Material(color = Color.green()))
        ef_el = [ef_tf_L,ef_tf_R,ef_bf,ef_web_L,ef_web_R]
        return ef_el


    def sag_slender_ef_els(self, web_slenderness, dNA_g):
        ef_tf_L = self.eff_top_flange(self.tf_slenderness,self.top_flange_L)
        ef_tf_R = self.eff_top_flange(self.tf_slenderness,self.top_flange_R)
        ef_web_L = self.eff_web(web_slenderness,self.web_L,'sag',dNA_g)
        ef_web_R = self.eff_web(web_slenderness,self.web_R,'sag',dNA_g)
        ef_bf = Polygon(self.bot_flange.shape.points, material=Material(color = Color.green()))
        ef_el = [ef_tf_L,ef_tf_R,ef_bf]+ef_web_L+ef_web_R
        return ef_el


    def hog_slender_ef_els(self, web_slenderness, dNA_g):
        ef_tf_L = Polygon(self.top_flange_L.shape.points, material=Material(color = Color.blue()))
        ef_tf_R = Polygon(self.top_flange_R.shape.points, material=Material(color = Color.blue()))
        ef_web_L = self.eff_web(web_slenderness,self.web_L,'hog',dNA_g)
        ef_web_R = self.eff_web(web_slenderness,self.web_R,'hog',dNA_g)
        ef_bf = self.eff_bot_flange(self.bf_slenderness, self.bot_flange)
        ef_el = [ef_tf_L,ef_tf_R,ef_bf]+ef_web_L+ef_web_R
        return ef_el


    def calc_ef_properties(self, web_slenderness, dNA_g, ls, lsy, lsp, S_or_H):   
        #print('In tg_NC_sag calc_properties') 
        if ls < lsp:
            self.ef_el = self.compact_ef_els()
            self.section_props_ef = tg_section_props(self.ef_el)
            self.Zxef = self.section_props_ef.Zex
            self.ef_status = 'Section is compact'
        elif ls < lsy:
            self.ef_el = self.compact_ef_els()
            self.section_props_ef = tg_section_props(self.ef_el)
            self.Zxef = self.section_props_ef.Zx
            self.ef_status = 'Section is Not compact'
        else:
            if S_or_H == 'S':
                self.ef_el = self.sag_slender_ef_els(web_slenderness, dNA_g)
            else:
                self.ef_el = self.hog_slender_ef_els(web_slenderness, dNA_g)
            self.section_props_ef = tg_section_props(self.ef_el)
            self.Zxef = self.section_props_ef.Zex
            self.ef_status = 'Section is NOT compact (slender)'
        
        self.phiMsx = 0.9*self.Zxef*self.fy
        self.Aef = self.section_props_ef.A*ureg('m**2')
        self.dNA_ef = self.section_props_ef.dNA*ureg('m')
        self.Ix_ef = self.section_props_ef.Ix*ureg('m**4')
        self.dEAA_ef = self.section_props_ef.dEAA*ureg('m')
        self.Zx_top_ef = self.section_props_ef.Zx_top*ureg('m**3')
        self.Zx_bot_ef = self.section_props_ef.Zx_bot*ureg('m**3')
        self.dEAA_ef = self.section_props_ef.dEAA*ureg('m')


    def calc_web_slenderness(self, web_L_b,
                                web_t,
                                yield_strength,
                                d1,
                                red1,
                                rpd1)->WebSlenderness:
        web_slenderness = WebSlenderness(web_L_b,
                                         web_t,
                                         yield_strength,
                                         d1,
                                         red1,
                                         rpd1)
        return web_slenderness


    def gross_section_props(self, gross_elements:list):   
        self.section_props_g = tg_section_props(self.gross_elements)
        self.A_g = self.section_props_g.A*ureg('m**2')
        self.dNA_g = self.section_props_g.dNA*ureg('m')
        self.Ix_g = self.section_props_g.Ix*ureg('m**4')
        self.dEAA_g = self.section_props_g.dEAA*ureg('m')
        self.Zx_top_g = self.section_props_g.Zx_top*ureg('m**3')
        self.Zx_bot_g = self.section_props_g.Zx_bot*ureg('m**3')
        

    def eff_bot_flange(self, slenderness:BottomFlangeSlenderness, bot_flange:BottomFlange1)->Polygon:
        bef = min((slenderness.ley*bot_flange.flange.t)/(bot_flange.flange.yield_strength/(250*ureg.MPa))**0.5,bot_flange.flange.b)

        shape_ef = Polygon([Point(-bef.m/2, -(bot_flange.geometry.D.m-bot_flange.flange.t.m)),
                               Point(bef.m/2, -(bot_flange.geometry.D.m-bot_flange.flange.t.m)),
                                 Point(bef.m/2, -bot_flange.geometry.D.m),
                                   Point(-bef.m/2, -bot_flange.geometry.D.m)],
                                   material=Material(color = Color.green())
                                   )
        return shape_ef


    def eff_top_flange(self, slenderness:TopFlangeSlenderness, top_flange:TopFlange1)->Polygon:
        
        outstand_ef = min((slenderness.ley*top_flange.flange.t)/(top_flange.flange.yield_strength/(250*ureg.MPa))**0.5,top_flange.flange.b/2)
        bef = 2*outstand_ef

        if top_flange.side == 'L':
            shape_ef = Polygon([Point(-(bef.m/2+top_flange.geometry.w_top.m/2), -(0.0)),
                                    Point(-(-bef.m/2+top_flange.geometry.w_top.m/2), -(0.0)),
                                    Point(-(-bef.m/2+top_flange.geometry.w_top.m/2), -(top_flange.flange.t.m)),
                                    Point(-(bef.m/2+top_flange.geometry.w_top.m/2), -(top_flange.flange.t.m))],
                                    material = top_flange.mat
                                    )
        else:
            shape_ef = Polygon([Point((bef.m/2+top_flange.geometry.w_top.m/2), -(0.0)),
                                    Point((-bef.m/2+top_flange.geometry.w_top.m/2), -(0.0)),
                                    Point((-bef.m/2+top_flange.geometry.w_top.m/2), -(top_flange.flange.t.m)),
                                    Point((bef.m/2+top_flange.geometry.w_top.m/2), -(top_flange.flange.t.m))],
                                    material = top_flange.mat
                                    )
        return shape_ef


    def eff_web(self, slenderness:WebSlenderness, web:Web11, bending_state:str, dNA_g)->list[Polygon]:
        # print('In eff_web, dNA_g: ',dNA_g)
        self.web_d_below_NA = self.geometry.D-dNA_g-self.bot_flange.flange.t
        self.web_d_above_NA = dNA_g-self.top_flange_L.flange.t
        self.d1 = self.web_d_below_NA+self.web_d_above_NA 

        if bending_state == 'sag':
            if slenderness.le_ratio > 1:
                self.web_lower_d_ef = self.web_d_below_NA+min(28*self.web_L.web.t/(self.web_L.web.yield_strength/(250*ureg.MPa))**0.5,self.web_d_above_NA/2)
                self.web_upper_d_ef = min(28*self.web_L.web.t/(self.web_L.web.yield_strength/(250*ureg.MPa))**0.5,self.web_d_above_NA/2)
            else:
                self.web_lower_d_ef = self.web_d_below_NA + self.web_d_above_NA/2
                self.web_upper_d_ef = self.web_d_above_NA/2
        else: 
            if slenderness.le_ratio > 1:
                self.web_lower_d_ef = min(28*self.web_L.web.t/(self.web_L.web.yield_strength/(250*ureg.MPa))**0.5,self.web_d_below_NA/2)
                self.web_upper_d_ef = self.web_d_above_NA+min(28*self.web_L.web.t/(self.web_L.web.yield_strength/(250*ureg.MPa))**0.5,self.web_d_below_NA/2)
            else:
                self.web_lower_d_ef = self.web_d_below_NA/2 
                self.web_upper_d_ef = self.web_d_above_NA + self.web_d_below_NA/2

        if web.side == 'L':
            #############
            # Left Side #
            #############
            self.web_x_at_upper_d_ef = (web.shape.points[0][0] + (self.web_upper_d_ef).m*tan(web.slope))
            
            web_top_ef = Polygon(([self.web_L.shape.points[0],
                                    self.web_L.shape.points[1],
                                    Point(self.web_x_at_upper_d_ef+self.web_L.web.t.m/cos(self.web_L.slope),-self.web_upper_d_ef.m-self.top_flange_L.flange.t.m),
                                    Point(self.web_x_at_upper_d_ef,-self.web_upper_d_ef.m-self.top_flange_L.flange.t.m)
                                    ]), material = web.mat)

            self.web_x_at_lower_d_ef = (self.web_L.shape.points[3][0] - (self.web_lower_d_ef).m*tan(self.web_L.slope))
            self.web_y_at_lower_d_ef = (self.web_L.shape.points[2][1]+self.web_lower_d_ef.m)

            
            web_bot_ef = Polygon(([self.web_L.shape.points[2],
                                        self.web_L.shape.points[3],
                                        Point(self.web_x_at_lower_d_ef,self.web_y_at_lower_d_ef),
                                        Point(self.web_x_at_lower_d_ef+self.web_L.web.t.m/cos(self.web_L.slope),self.web_y_at_lower_d_ef),
                                        ]), material = web.mat)
        else:
            #############
            # Right Side #
            #############
            self.web_x_at_upper_d_ef_R = (self.web_R.shape.points[0][0] - (self.web_upper_d_ef).m*tan(self.web_R.slope))
            
            web_top_ef = Polygon(([self.web_R.shape.points[0],
                                        self.web_R.shape.points[1],
                                        Point(self.web_x_at_upper_d_ef_R-self.web_R.web.t.m/cos(self.web_R.slope),-self.web_upper_d_ef.m-self.top_flange_R.flange.t.m),
                                        Point(self.web_x_at_upper_d_ef_R,-self.web_upper_d_ef.m-self.top_flange_R.flange.t.m)
                                        ]), material = web.mat)
            
            self.web_x_at_lower_d_ef_R = (self.web_R.shape.points[3][0] + (self.web_lower_d_ef).m*tan(self.web_R.slope))
            self.web_y_at_lower_d_ef_R = (self.web_R.shape.points[2][1] + self.web_lower_d_ef.m)

            
            web_bot_ef = Polygon(([self.web_R.shape.points[2],
                                        self.web_R.shape.points[3],
                                        Point(self.web_x_at_lower_d_ef_R,self.web_y_at_lower_d_ef_R),
                                        Point(self.web_x_at_lower_d_ef_R - self.web_R.web.t.m/cos(self.web_R.slope),self.web_y_at_lower_d_ef_R),
                                        ]), material = web.mat)
        return [web_top_ef, web_bot_ef]
    
    
    def section_slenderness(self, el_slenderness:list[ElementSlenderness]):
        self.el_sl = el_slenderness

        crit_el = max(self.el_sl, key = lambda x: x.slenderness_ratio())
        ls = crit_el.element_slenderness()
        lsy = crit_el.ley
        lsp = crit_el.lep
        return ls, lsy, lsp

