import json
import pandas as pd
import networkx as nx
from math import sqrt
import plotly.graph_objects as go
import plotly.express as px

# Function to extract group ID and names into a list
def extract_keys_at_level(data, target_level, target_key, current_level=1):
    keys_and_names = []
    
    if current_level == target_level:
        for key, value in data.items():
            if isinstance(value, dict) and target_key in value:
                keys_and_names.append( f'{key}: {value[target_key]}')
    else:
        for key, value in data.items():
            if isinstance(value, dict):
                keys_and_names.extend(
                    extract_keys_at_level(value, target_level, target_key, current_level + 1)
                )
    return keys_and_names


# Function to get a list of elements in a particular group
def get_elements_by_group(json_obj:json, key_path):
    # Traverse the JSON object using the key path 
    # Key path will be similar to ['GRUP','37','E_LIST'] or ['GRUP','37','E_LIST'] 
    for key in key_path:
        json_obj = json_obj.get(key, {})
    # Extract the data you want
    subject_elems = []
    if isinstance(json_obj, list):
        for elem in json_obj:
            subject_elems.append(elem)
    return subject_elems


def get_subject_elems(all_elems, subject_elems):
    """ reduced_list = []
    for elem_id in all_elems.ELEM:
        if int(elem_id) in subject_elems:
            reduced_list.append({
                "Element ID": elem_id,
                "Node i": node_i,
                "Node j": node_j,
                "Section Type ID": section
                }) """
    #print(reduced_list)
    group_elements = {"ELEM":{}}
    for elem_id in subject_elems:
        if str(elem_id) in all_elems["ELEM"]:
            group_elements["ELEM"][str(elem_id)] = all_elems["ELEM"][str(elem_id)]
    #print(group_elements)


    elem_data = pd.DataFrame(group_elements)    
    #print(group_elements)
    return group_elements


def get_subject_nodes(all_nodes, subject_nodes):
    group_nodes = {"NODE":{}}
    for node_id in subject_nodes:
        if str(node_id) in all_nodes["NODE"]:
            group_nodes["NODE"][str(node_id)] = all_nodes["NODE"][str(node_id)]
    #print(group_nodes)


    node_data = pd.DataFrame(group_nodes)    
    #print(group_nodes)
    return group_nodes


# Function to calculate the length of an element(edge)
def calc_edge_length(node1, node2):
    x1, y1 = node1['X'], node1['Y']
    x2, y2 = node2['X'], node2['Y']
    return sqrt((x2-x1)**2+(y2-y1)**2)  

# Function to create the graph object based on the selected nodes and elements
def create_graph(group_nodes, group_elements, design_action_data):
    # Create an empty graph object
    g = nx.Graph()
    # Add the nodes with attributes
    for node_id, attributes in group_nodes['NODE'].items():
        #print(node_id, attributes)
        g.add_node(node_id, **attributes)
    # Print the nodes
    #for node in g.nodes(data=True):
    #    print(node)
     
    # Add the elements
    for elem_id, attributes in group_elements['ELEM'].items():
        node_list = attributes.pop('NODE')
        start_node, end_node = node_list[:2]
        attributes['elem_ID'] = elem_id
        g.add_edge(start_node, end_node, ** attributes)
    # Print the edge data
    #for edge in g.edges(data=True):
    #    print(edge)
    
    
    # Add the length as an attribute to each edge(element)
    for u, v in g.edges():
        node1 = g.nodes[str(u)]
        node2 = g.nodes[str(v)]
        length = calc_edge_length(node1, node2)
        g[u][v]['LENG'] = length

    # Print the length of each edge(element)
    #for u,v,data in g.edges(data=True):
    #    print(f'Element {data['elem_ID']}, ({u},{v}) has length {data['LENG']}')
    
    # Assign the design action data to the edges
    for edge in g.edges(data=True):
        # edge[0] is node I, edge[1] is node J in the graph object
        #print(edge)
        for elem_id in design_action_data['BeamForce']['DATA']:
            #print(elem_id)
            if edge[2]['elem_ID'] == elem_id[1]:
                if elem_id[3].startswith('I['):
                    #print(f'{type(elem_id[3][2:-1])} is equal to {type(edge[0])}')
                    if int(elem_id[3][2:-1]) == edge[0]:
                        edge[2][str(edge[0])] = {'Ax':float(elem_id[4]),
                                                 'Vy':float(elem_id[5]),
                                                 'Vz':float(elem_id[6]),
                                                 'Mx':float(elem_id[7]),
                                                 'My':float(elem_id[8]),
                                                 'Mz':float(elem_id[9])}
                        
                elif elem_id[3].startswith('J['):
                    if int(elem_id[3][2:-1]) == edge[1]:
                        edge[2][str(edge[1])] = {'Ax':float(elem_id[4]),
                                                 'Vy':float(elem_id[5]),
                                                 'Vz':float(elem_id[6]),
                                                 'Mx':float(elem_id[7]),
                                                 'My':float(elem_id[8]),
                                                 'Mz':float(elem_id[9])}
        #print(edge)
    
    
    
    # Find the start node and save it as an attribute of the graph
    single_degree_nodes = [node for node, degree in g.degree() if degree == 1]
    #print(single_degree_nodes)
    if g.nodes[str(single_degree_nodes[0])]['X'] < g.nodes[str(single_degree_nodes[1])]['X']:
        start_node = single_degree_nodes[0]
    else:
        start_node = single_degree_nodes[1]
    #print(g.nodes[str(start_node)]['X'])
    g.graph['start_node'] = start_node
    
    #for i in range(0,len(single_degree_nodes)):
    #    print(g.nodes[str(single_degree_nodes[i])]['X'])

    ordered_nodes = nx.bfs_tree(g, start_node).nodes
    #print(ordered_nodes)

    return g

# Function to calculate the culumative positions along the graph
def calculate_positions(G):
    positions = {}
    current_x = 0
    current_node = G.graph['start_node']
    positions[current_node] = (current_x, 0)

    for u, v, data in G.edges(data=True):
        if u == current_node:
            current_x += data['LENG']
            positions[v] = (current_x, 0)
            current_node = v
        elif v == current_node:
            current_x += data['LENG']
            positions[u] = (current_x, 0)
            current_node = u
    return positions

# Function to get colours for the line based on section type
def assign_colors(G):
    sect_types = set(data['SECT'] for _, _, data in G.edges(data=True))
    colors = px.colors.qualitative.Plotly
    sect_colors = {sect: colors[i % len(colors)] for i, sect in enumerate(sect_types)}
    return sect_colors

# Function to plot the line
def plot_graph(G, positions, sect_colors, node_mode, subject_design_action):
    fig = go.Figure()
    #print(positions)

    for node, (x, y) in positions.items():
        fig.add_trace(go.Scatter(x=[x], y=[y], mode=node_mode, marker=dict(color='black'), text=[node], textposition='top center', showlegend=False))

    design_action = {}
    for u, v, data in G.edges(data=True):
        #print(data)
        #print(data[str(u)]['My'], data[str(v)]['My'])
        #print(positions[u][0], positions[v][0])
        x0 = positions[u][0]
        y0 = data[str(u)][subject_design_action]
        x1 = positions[v][0]
        y1 = data[str(v)][subject_design_action]
        #print(x0, y0, x1, y1)
        fig.add_trace(go.Scatter(x=[x0, x1], y=[y0, y1], mode='lines', line=dict(width=2, color='red'), name=subject_design_action, showlegend=True))
    
    
    
    edges_by_sect = {}
    for u, v, data in G.edges(data=True):
        sect = data['SECT']
        if sect not in edges_by_sect:
            edges_by_sect[sect] = []
        edges_by_sect[sect].append((u, v, data))

    for sect, edges in edges_by_sect.items():
        for u, v, data in edges:
            x0, y0 = positions[u]
            x1, y1 = positions[v]
            color = sect_colors.get(data['SECT'], 'black')
            fig.add_trace(go.Scatter(x=[x0, x1], y=[y0, y1], mode='lines', line=dict(width=2, color=color), name=f"SECT {sect}", showlegend=True))

    fig.for_each_trace(lambda trace: trace.update(showlegend=False))
    unique_legends = set()
    for trace in fig.data:
        legend_name = trace.name
        if legend_name not in unique_legends:
            trace.update(showlegend=True)
            unique_legends.add(legend_name)

    fig.update_layout(title='Graph Plot', xaxis_title='Chainage', yaxis_title='Y', showlegend=True, yaxis=dict(autorange="reversed"))

    return fig

def get_node_mode(selections):
    if len(selections) == 0:
        return 'none'
    elif len(selections) == 1:
        if selections[0] == 'Node Numbers':
            return 'text'
        else:
            return 'markers'
    else:
        return 'markers+text'

def get_design_actions(load_case, group):
    return {
    "Argument": {
        "TABLE_NAME": "BeamForce",
        "TABLE_TYPE": "BEAMFORCE",
        #"EXPORT_PATH": "C:\\MIDAS\\Result\\Output.JSON",
        "UNIT": {
            "FORCE": "kN",
            "DIST": "m"
        },
        "STYLES": {
            "FORMAT": "Fixed",
            "PLACE": 6
        },
        "COMPONENTS": [
            "Elem",
            "Load",
            "Part",
            "Axial",
            "Shear-y",
            "Shear-z",
            "Torsion",
            "Moment-y",
            "Moment-z",
            "Bi-Moment",
            "T-Moment",
            "W-Moment"
        ],
        "NODE_ELEMS": {
                "STRUCTURE_GROUP_NAME": group
            },
        "LOAD_CASE_NAMES": [
            load_case+"(CB:min)"# Should un-hard code this somehow
        ],
        "PARTS": [
            "PartI",
            "PartJ"
        ]
    }
}
