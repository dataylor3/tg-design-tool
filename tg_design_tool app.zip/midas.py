import requests
import json

class MidasAPIClass():
    def __init__(self, base_url:str,mapi_key:str):
        self.base_url = base_url
        self.mapi_key = mapi_key
   
    # Method for MIDAS Open API
    def MidasAPI(self, method, command, body=None):
        base_url = self.base_url
        mapi_key = self.mapi_key

        url = base_url + command
        headers = {
            "Content-Type": "application/json",
            "MAPI-Key": mapi_key
        }

        if method == "POST":
            response = requests.post(url=url, headers=headers, json=body)
        elif method == "PUT":
            response = requests.put(url=url, headers=headers, json=body)
        elif method == "GET":
            response = requests.get(url=url, headers=headers)
        elif method == "DELETE":
            response = requests.delete(url=url, headers=headers)

        #print(method, command, response.status_code)
        #return response.status_code 
        return response.json(), response.status_code 

    def project_info():
        #Create project infor body
        pass