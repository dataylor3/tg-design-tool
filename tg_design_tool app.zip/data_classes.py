from viktor.geometry import Point, Polygon, Vector, Material, Color 
from unit_registry import ureg, Q_
from element_slenderness import ElementSlenderness, TopFlangeSlenderness, BottomFlangeSlenderness
from math import sin, cos, tan, asin, acos, atan, pi, ceil
from concrete_tools import get_Ecj, get_reo_area


# Classes to hold the input data
class Reinforcement(): # Holds the input data
    def __init__(self, top_reo_name:str, top_reo_s:Q_, top_reo_d:Q_,
                 bot_reo_name:str, bot_reo_s:Q_, bot_reo_d:Q_):
        self.top_reo_name = top_reo_name
        self.top_reo_s = top_reo_s
        self.top_reo_d = top_reo_d
        self.bot_reo_name = bot_reo_name
        self.bot_reo_s = bot_reo_s
        self.bot_reo_d = bot_reo_d

class Deck(): # Holds input data
    def __init__(self, deck_w_L, deck_w_R, deck_D, deck_ef_w_per_flange,
                 deck_conc_str,  deck_precast_d, deck_haunch_d,deck_haunch_w) -> None:
        self.deck_w_L = deck_w_L
        self.deck_w_R = deck_w_R
        self.deck_D = deck_D
        self.deck_ef_w_per_flange = deck_ef_w_per_flange
        self.deck_conc_str = deck_conc_str
        self.deck_precast_d = deck_precast_d
        self.deck_haunch_d = deck_haunch_d
        self.deck_haunch_w = deck_haunch_w
        

class SectionGeometry1(): # Holds input data
    def __init__(self, D, w_top, w_bot):
        self.D = D
        self.w_top = w_top
        self.w_bot = w_bot

class Flange1():    # Holds input data
    def __init__(self, b:Q_, t:Q_, yield_strength:Q_, stress_state:str):
        self.b = b
        self.t = t
        self.yield_strength = yield_strength
        self.stress_state = stress_state

class Web1():   # Holds input data
    def __init__(self, t, yield_strength, stress_state:str):
        self.t = t
        self.yield_strength = yield_strength
        self.stress_state = stress_state

# Classes to create the elements
class Deck1():
    def __init__(self, geometry:SectionGeometry1, deck:Deck) -> None:
        self.geometry = geometry
        self.deck = deck
        precast_d = self.deck.deck_precast_d
        haunch_d = self.deck.deck_haunch_d
        haunch_w = self.deck.deck_haunch_w
        top_w = self.geometry.w_top
        self.deck_gross_shapes = []
        precast_shapes = []
        mat_conc_gross = Material(color = Color(255,255,251))
        mat_pc = Material(color = Color.lime())

        p1 = Point(-self.deck.deck_w_L.m, (self.deck.deck_D.m + precast_d.m + haunch_d.m))
        p2 = Point(self.deck.deck_w_R.m, (self.deck.deck_D.m + precast_d.m + haunch_d.m))
        p3 = Point(self.deck.deck_w_R.m, precast_d.m + haunch_d.m)
        p4 = Point((top_w.m/2 + haunch_w.m/2), precast_d.m + haunch_d.m)
        p5 = Point((top_w.m/2 + haunch_w.m/2), 0.0)
        p6 = Point((top_w.m/2 - haunch_w.m/2), 0.0)
        p7 = Point((top_w.m/2 - haunch_w.m/2), precast_d.m + haunch_d.m)
        p8 = Point((-top_w.m/2 + haunch_w.m/2), precast_d.m + haunch_d.m)
        p9 = Point((-top_w.m/2 + haunch_w.m/2), 0.0)
        p10 = Point((-top_w.m/2 - haunch_w.m/2), 0.0)
        p11 = Point((-top_w.m/2 - haunch_w.m/2), precast_d.m + haunch_d.m)
        p12 = Point(-self.deck.deck_w_L.m, precast_d.m + haunch_d.m)
        p13 = Point(self.deck.deck_w_R.m, haunch_d.m)
        p14 = Point((top_w.m/2 + haunch_w.m/2), haunch_d.m)
        p15 = Point((top_w.m/2 - haunch_w.m/2), haunch_d.m)
        p16 = Point((-top_w.m/2 + haunch_w.m/2), haunch_d.m)
        p17 = Point((-top_w.m/2 - haunch_w.m/2), haunch_d.m)
        p18 = Point(-self.deck.deck_w_L.m, haunch_d.m)

        # Create main deck shape
        if p5 != p4:
            shape = Polygon([p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12])
        else:
            shape = Polygon([p1,p2,p3,p12])
        self.deck_gross_shapes.append(shape)
        # Create the precast panel shapes if they exist
        if precast_d > 0:
            precast_shapes.append(Polygon([p12,p11,p17,p18], material=mat_pc))
            precast_shapes.append(Polygon([p8,p7,p15,p16], material=mat_pc))
            precast_shapes.append(Polygon([p4,p3,p13,p14], material=mat_pc))
            self.deck_gross_shapes += precast_shapes



class Deck1_hog(Deck1):
    def __init__(self, geometry:SectionGeometry1, deck:Deck, reo:Reinforcement):
        super().__init__(geometry, deck)
        # Colour for effective shape
        self.mat_ef = Material(color = Color.viktor_black())
        self.top_reo_s = reo.top_reo_s
        self.bot_reo_s = reo.bot_reo_s
        precast_d = self.deck.deck_precast_d
        haunch_d = self.deck.deck_haunch_d
        top_of_deck_y = deck.deck_D+precast_d+haunch_d
        try:
            self.top_reo_dia = ((4*get_reo_area(reo.top_reo_name))/pi)**0.5
        except TypeError:
            self.top_reo_dia = 0.0*ureg('mm')
        try:
            self.bot_reo_dia = ((4*get_reo_area(reo.bot_reo_name))/pi)**0.5
        except TypeError:
            self.bot_reo_dia = 0.0*ureg('mm')
        # print(self.top_reo_dia)
        self.ef_deck_shapes = []
        
        # If the effective flange width is less than the deck physical flange width
        if deck.deck_ef_w_per_flange < geometry.w_top:
            x_LL = max(-geometry.w_top/2-deck.deck_ef_w_per_flange/2,-deck.deck_w_L)
            x_LR = -geometry.w_top/2+deck.deck_ef_w_per_flange/2
            x_RL = geometry.w_top/2-deck.deck_ef_w_per_flange/2
            x_RR = min(geometry.w_top/2+deck.deck_ef_w_per_flange/2,deck.deck_w_R)

            # Polygons for top flange
            try: # Checking that there is some top reo selected
                half_top_reo_layer_depth = (1/reo.top_reo_s*get_reo_area(reo.top_reo_name))/2
            except TypeError:
                half_top_reo_layer_depth = 0*ureg('mm')
            if half_top_reo_layer_depth.m > 0:
            # Create 2 rectangular polygons to represent the reinforcement
                self.top_l_ef_shape = Polygon([Point(x_LL.m, (top_of_deck_y-reo.top_reo_d+half_top_reo_layer_depth).m),
                                    Point(x_LR.m, (top_of_deck_y-reo.top_reo_d+half_top_reo_layer_depth).m),
                                        Point(x_LR.m, (top_of_deck_y-reo.top_reo_d-half_top_reo_layer_depth).m),
                                        Point(x_LL.m, (top_of_deck_y-reo.top_reo_d-half_top_reo_layer_depth).m)],
                                        material = self.mat_ef
                                        )
                self.ef_deck_shapes.append(self.top_l_ef_shape)

                self.top_R_ef_shape = Polygon([Point(x_RL.m, (top_of_deck_y-reo.top_reo_d+half_top_reo_layer_depth).m),
                                    Point(x_RR.m, (top_of_deck_y-reo.top_reo_d+half_top_reo_layer_depth).m),
                                        Point(x_RR.m, (top_of_deck_y-reo.top_reo_d-half_top_reo_layer_depth).m),
                                        Point(x_RL.m, (top_of_deck_y-reo.top_reo_d-half_top_reo_layer_depth).m)],
                                        material = self.mat_ef
                                        )
                self.ef_deck_shapes.append(self.top_R_ef_shape)

            # Polygons for bottom reo
            # Checking that there is some bottom reo selected
            try:
                # half_bot_reo_layer_depth = (deck.deck_ef_w_per_flange/reo.bot_reo_s*get_reo_area(reo.bot_reo_name))/(deck.deck_ef_w_per_flange)/2
                half_bot_reo_layer_depth = (1/reo.bot_reo_s*get_reo_area(reo.bot_reo_name))/2
            except TypeError:
                half_bot_reo_layer_depth = 0*ureg('mm')
            if half_bot_reo_layer_depth.m >0:
            # Create 2 rectangular polygons to represent the reinforcement
                self.bot_l_ef_shape = Polygon([Point(x_LL.m, (top_of_deck_y-reo.bot_reo_d+half_bot_reo_layer_depth).m),
                                    Point(x_LR.m, (top_of_deck_y-reo.bot_reo_d+half_bot_reo_layer_depth).m),
                                        Point(x_LR.m, (top_of_deck_y-reo.bot_reo_d-half_bot_reo_layer_depth).m),
                                        Point(x_LL.m, (top_of_deck_y-reo.bot_reo_d-half_bot_reo_layer_depth).m)],
                                        material = self.mat_ef
                                        )
                self.ef_deck_shapes.append(self.bot_l_ef_shape)

                self.bot_R_ef_shape = Polygon([Point(x_RL.m, (top_of_deck_y-reo.bot_reo_d+half_bot_reo_layer_depth).m),
                                    Point(x_RR.m, (top_of_deck_y-reo.bot_reo_d+half_bot_reo_layer_depth).m),
                                        Point(x_RR.m, (top_of_deck_y-reo.bot_reo_d-half_bot_reo_layer_depth).m),
                                        Point(x_RL.m, (top_of_deck_y-reo.bot_reo_d-half_bot_reo_layer_depth).m)],
                                        material = self.mat_ef
                                        )
                self.ef_deck_shapes.append(self.bot_R_ef_shape)

        # If the effective flange width is limited by the deck physical flange width
        else:
            x_L = max(-geometry.w_top/2-deck.deck_ef_w_per_flange/2,-deck.deck_w_L)
            x_R = min(geometry.w_top/2+deck.deck_ef_w_per_flange/2,deck.deck_w_R)
            # Checking that there is some top reo selected
            try:
                half_top_reo_layer_depth = (1/reo.top_reo_s*get_reo_area(reo.top_reo_name))/2
            except TypeError:
                half_top_reo_layer_depth = 0*ureg('mm')
            
            if half_top_reo_layer_depth.m > 0:
            # Create a rectangular polygon to represent the reinforcement
                self.top_ef_shape = Polygon([Point(x_L.m, (top_of_deck_y-reo.top_reo_d+half_top_reo_layer_depth).m),
                                    Point(x_R.m, (top_of_deck_y-reo.top_reo_d+half_top_reo_layer_depth).m),
                                        Point(x_R.m, (top_of_deck_y-reo.top_reo_d-half_top_reo_layer_depth).m),
                                        Point(x_L.m, (top_of_deck_y-reo.top_reo_d-half_top_reo_layer_depth).m)],
                                        material = self.mat_ef
                                        )
                self.ef_deck_shapes.append(self.top_ef_shape)

            try: # Checking that there is some bottom reo selected   
                half_bot_reo_layer_depth = (1/reo.bot_reo_s*get_reo_area(reo.bot_reo_name))/2
            except TypeError:
                half_bot_reo_layer_depth = 0*ureg('mm')
            if half_bot_reo_layer_depth.m >0:
            # Create a rectangular polygon to represent the reinforcement
                self.bot_ef_shape = Polygon([Point(x_L.m, (top_of_deck_y-reo.bot_reo_d+half_bot_reo_layer_depth).m),
                                    Point(x_R.m, (top_of_deck_y-reo.bot_reo_d+half_bot_reo_layer_depth).m),
                                        Point(x_R.m, (top_of_deck_y-reo.bot_reo_d-half_bot_reo_layer_depth).m),
                                        Point(x_L.m, (top_of_deck_y-reo.bot_reo_d-half_bot_reo_layer_depth).m)],
                                        material = self.mat_ef
                                        )
                self.ef_deck_shapes.append(self.bot_ef_shape)


class Deck1_sag(Deck1):
    def __init__(self, geometry:SectionGeometry1, deck:Deck, fy:Q_) -> None:
        super().__init__(geometry, deck)
        # Colour for effective shape
        self.mat_ef = Material(color = Color.viktor_black())
        # Concrete modulus of elasticity
        self.Ecj = get_Ecj(deck.deck_conc_str)
        # Modular ratio
        self.n = (200*10**3)*ureg('MPa')/self.Ecj
        # Transformed effective deck width per flange
        self.trans_ef_w_per_flange = deck.deck_ef_w_per_flange/self.n
        # List for the effective shapes
        self.ef_deck_shapes = []
        # Haunch details
        precast_d = self.deck.deck_precast_d
        haunch_d = self.deck.deck_haunch_d
        haunch_w = self.deck.deck_haunch_w
        top_of_deck_y = deck.deck_D+precast_d+haunch_d
        
        if self.trans_ef_w_per_flange <= haunch_w:
            if self.trans_ef_w_per_flange < geometry.w_top:
                # Polygon for left flange
                x_LL = -geometry.w_top/2-self.trans_ef_w_per_flange/2
                x_LR = -geometry.w_top/2+self.trans_ef_w_per_flange/2
                self.l_ef_shape = Polygon([Point(x_LL.m, top_of_deck_y.m),
                                    Point(x_LR.m, top_of_deck_y.m),
                                        Point(x_LR.m, 0.0),
                                        Point(x_LL.m, 0.0)],
                                        material = self.mat_ef
                                        )
                self.ef_deck_shapes.append(self.l_ef_shape)
                # Polygon for right flange
                x_RL = geometry.w_top/2-self.trans_ef_w_per_flange/2
                x_RR = geometry.w_top/2+self.trans_ef_w_per_flange/2
                self.R_ef_shape = Polygon([Point(x_RL.m, top_of_deck_y.m),
                                    Point(x_RR.m, top_of_deck_y.m),
                                        Point(x_RR.m, 0.0),
                                        Point(x_RL.m, 0.0)],
                                        material = self.mat_ef
                                        )
                self.ef_deck_shapes.append(self.R_ef_shape)
            else:
                x_L = -self.trans_ef_w_per_flange/2
                x_R = +self.trans_ef_w_per_flange/2
                self.ef_shape = Polygon([Point(x_L.m, top_of_deck_y.m),
                                    Point(x_R.m, top_of_deck_y.m),
                                        Point(x_R.m, 0.0),
                                        Point(x_L.m, 0.0)],
                                        material = self.mat_ef
                                        )
                self.ef_deck_shapes.append(self.ef_shape)
        else:
            p1 = Point(-geometry.w_top.m/2-self.trans_ef_w_per_flange.m/2, (top_of_deck_y.m))
            p2 = Point(-geometry.w_top.m/2+self.trans_ef_w_per_flange.m/2, (top_of_deck_y.m))
            p3 = Point(-geometry.w_top.m/2+self.trans_ef_w_per_flange.m/2, (top_of_deck_y.m - deck.deck_D.m))
            p4 = Point(-geometry.w_top.m/2+haunch_w.m/2, (top_of_deck_y.m - deck.deck_D.m))
            p5 = Point(-geometry.w_top.m/2+haunch_w.m/2, 0.0)
            p6 = Point(-geometry.w_top.m/2-haunch_w.m/2, 0.0)
            p7 = Point(-geometry.w_top.m/2-haunch_w.m/2, (top_of_deck_y.m - deck.deck_D.m))
            p8 = Point(-geometry.w_top.m/2-self.trans_ef_w_per_flange.m/2, (top_of_deck_y.m - deck.deck_D.m))
            p9 = Point(geometry.w_top.m/2-self.trans_ef_w_per_flange.m/2, (top_of_deck_y.m))
            p10 = Point(geometry.w_top.m/2+self.trans_ef_w_per_flange.m/2, (top_of_deck_y.m))
            p11 = Point(geometry.w_top.m/2+self.trans_ef_w_per_flange.m/2, (top_of_deck_y.m - deck.deck_D.m))
            p12 = Point(geometry.w_top.m/2+haunch_w.m/2, (top_of_deck_y.m - deck.deck_D.m))
            p13 = Point(geometry.w_top.m/2+haunch_w.m/2, 0.0)
            p14 = Point(geometry.w_top.m/2-haunch_w.m/2, 0.0)
            p15 = Point(geometry.w_top.m/2-haunch_w.m/2, (top_of_deck_y.m - deck.deck_D.m))
            p16 = Point(geometry.w_top.m/2-self.trans_ef_w_per_flange.m/2, (top_of_deck_y.m - deck.deck_D.m))
            if haunch_d > 0 or precast_d > 0:
                self.l_ef_shape = Polygon([p1,p2,p3,p4,p5,p6,p7,p8], material = self.mat_ef)
                self.r_ef_shape = Polygon([p9,p10,p11,p12,p13,p14,p15,p16], material = self.mat_ef)
                self.ef_deck_shapes.append(self.l_ef_shape)
                self.ef_deck_shapes.append(self.r_ef_shape)
            else:
                self.l_ef_shape = Polygon([p1,p2,p3,p8], material = self.mat_ef)
                self.r_ef_shape = Polygon([p9,p10,p11,p16], material = self.mat_ef)
                self.ef_deck_shapes.append(self.l_ef_shape)
                self.ef_deck_shapes.append(self.r_ef_shape)


    

class BottomFlange1():
    def __init__(self, geometry:SectionGeometry1, flange:Flange1):
        self.geometry = geometry
        self.flange = flange
        self.mat_gross = Material(color = Color.green())
        self.mat_ef = Material(color = Color.viktor_yellow())
        self.el_slenderness = BottomFlangeSlenderness(self.flange.b,
                                                   self.flange.t,
                                                   self.flange.yield_strength,
                                                   self.flange.stress_state)


        self.shape = Polygon([Point(-self.flange.b.m/2, -(self.geometry.D.m-self.flange.t.m)),
                               Point(self.flange.b.m/2, -(self.geometry.D.m-self.flange.t.m)),
                                 Point(self.flange.b.m/2, -self.geometry.D.m),
                                   Point(-self.flange.b.m/2, -self.geometry.D.m)],
                                   )
        
        self.plate_element_slenderness = self.el_slenderness.element_slenderness()
        self.lep = self.el_slenderness.lep
        self.ley = self.el_slenderness.ley
        self.led = self.el_slenderness.led

        self.slenderness_ratio = self.el_slenderness.slenderness_ratio()

        if self.plate_element_slenderness > self.lep:
            self.bef = min((self.ley*self.flange.t)/(self.flange.yield_strength/(250*ureg.MPa))**0.5,self.flange.b)
        else:
            self.bef = self.flange.b

        self.shape_ef = Polygon([Point(-self.bef.m/2, -(self.geometry.D.m-self.flange.t.m)),
                               Point(self.bef.m/2, -(self.geometry.D.m-self.flange.t.m)),
                                 Point(self.bef.m/2, -self.geometry.D.m),
                                   Point(-self.bef.m/2, -self.geometry.D.m)],
                                   material = self.mat_gross
                                   )

class TopFlange1():
    def __init__(self, geometry:SectionGeometry1, flange:Flange1, side:str):
        self.geometry = geometry
        self.flange = flange
        self.side = side
        self.mat = Material('Steel', color = Color.blue())
        self.b = self.flange.b/2
        self.el_slenderness = TopFlangeSlenderness(self.b,
                                                   self.flange.t,
                                                   self.flange.yield_strength,
                                                   self.flange.stress_state)

        if self.side == 'L':
            self.shape = Polygon([Point(-(self.flange.b.m/2+self.geometry.w_top.m/2), -(0.0)),
                                Point(-(-self.flange.b.m/2+self.geometry.w_top.m/2), -(0.0)),
                                    Point(-(-self.flange.b.m/2+self.geometry.w_top.m/2), -(self.flange.t.m)),
                                    Point(-(self.flange.b.m/2+self.geometry.w_top.m/2), -(self.flange.t.m))]
                                    )
        else:
            self.shape = Polygon([Point((self.flange.b.m/2+self.geometry.w_top.m/2), -(0.0)),
                                Point((-self.flange.b.m/2+self.geometry.w_top.m/2), -(0.0)),
                                    Point((-self.flange.b.m/2+self.geometry.w_top.m/2), -(self.flange.t.m)),
                                    Point((self.flange.b.m/2+self.geometry.w_top.m/2), -(self.flange.t.m))]
                                    )

        self.plate_element_slenderness = self.el_slenderness.element_slenderness()
        self.lep = self.el_slenderness.lep
        self.ley = self.el_slenderness.ley
        self.led = self.el_slenderness.led

        self.slenderness_ratio = self.el_slenderness.slenderness_ratio()

        if self.plate_element_slenderness > self.lep:
            self.outstand_ef = min((self.ley*self.flange.t)/(self.flange.yield_strength/(250*ureg.MPa))**0.5,self.flange.b/2)
        else:
            self.outstand_ef = self.flange.b/2

        self.bef = 2*self.outstand_ef

        if self.side == 'L':
            self.shape_ef = Polygon([Point(-(self.bef.m/2+self.geometry.w_top.m/2), -(0.0)),
                                    Point(-(-self.bef.m/2+self.geometry.w_top.m/2), -(0.0)),
                                    Point(-(-self.bef.m/2+self.geometry.w_top.m/2), -(self.flange.t.m)),
                                    Point(-(self.bef.m/2+self.geometry.w_top.m/2), -(self.flange.t.m))],
                                    material = self.mat
                                    )
        else:
            self.shape_ef = Polygon([Point((self.bef.m/2+self.geometry.w_top.m/2), -(0.0)),
                                    Point((-self.bef.m/2+self.geometry.w_top.m/2), -(0.0)),
                                    Point((-self.bef.m/2+self.geometry.w_top.m/2), -(self.flange.t.m)),
                                    Point((self.bef.m/2+self.geometry.w_top.m/2), -(self.flange.t.m))],
                                    material = self.mat
                                    )

class Web11():
    def __init__(self, geometry:SectionGeometry1, web:Web1, top_flange:TopFlange1, bot_flange:BottomFlange1, side:str) -> None:
        self.geometry = geometry
        self.web = web
        self.top_flange = top_flange
        self.bot_flange = bot_flange
        self.side = side
        self.slope = atan((self.geometry.w_top-self.geometry.w_bot)/2/(self.geometry.D-self.top_flange.flange.t-self.bot_flange.flange.t))
        self.b = (((self.geometry.w_top-self.geometry.w_bot)/2)**2+(self.geometry.D-self.top_flange.flange.t-self.bot_flange.flange.t)**2)**0.5
        self.mat = Material('Steel', color = Color.red())

        if self.side == 'L':
            self.shape = Polygon([Point(-(self.geometry.w_top.m/2), -self.top_flange.flange.t.m),
                                  Point(-(self.geometry.w_top.m/2-self.web.t.m/cos(self.slope)), -self.top_flange.flange.t.m),
                                  Point(-(self.geometry.w_bot.m/2-self.web.t.m/cos(self.slope)), -(self.geometry.D.m-self.bot_flange.flange.t.m)),
                                  Point(-(self.geometry.w_bot.m/2), -(self.geometry.D.m-self.bot_flange.flange.t.m))],
                                    )
        else:
            self.shape = Polygon([Point((self.geometry.w_top.m/2), -self.top_flange.flange.t.m),
                                  Point((self.geometry.w_top.m/2-self.web.t.m/cos(self.slope)), -self.top_flange.flange.t.m),
                                  Point((self.geometry.w_bot.m/2-self.web.t.m/cos(self.slope)), -(self.geometry.D.m-self.bot_flange.flange.t.m)),
                                  Point((self.geometry.w_bot.m/2), -(self.geometry.D.m-self.bot_flange.flange.t.m))],
                                    )

        self.plate_element_slenderness = self.b/self.web.t*(self.web.yield_strength/(250*ureg.MPa))**0.5

        def ElasticProperties(elements:list[Polygon]):
            fmoa = 0    # First moment of area
            A = 0
            for el in elements:
                A += el.cross_sectional_area
                fmoa += el.cross_sectional_area*el.centroid[1]
            dna = fmoa/-A
            return dna*ureg('m')

        self.gross_section_elements: list[Polygon] = [self.top_flange.shape,
                                                    self.top_flange.shape,
                                                    self.shape,
                                                    self.shape,
                                                    self.bot_flange.shape]
        
        self.dna = ElasticProperties(self.gross_section_elements)

        self.web_re = (self.dna-self.top_flange.flange.t)/(self.geometry.D-self.top_flange.flange.t-self.bot_flange.flange.t)
        self.ley = 60/self.web_re
        self.slenderness_ratio = self.plate_element_slenderness/self.ley


"""
class TroughGirderSection():
    def __init__(self, top_flange_L:TopFlange1, top_flange_R:TopFlange1, web_L:Web11, web_R:Web11, bottom_flange:BottomFlange1):
        self.top_flange_L = top_flange_L
        self.top_flange_R = top_flange_R
        self.web_L = web_L
        self.web_R = web_R
        self.bottom_flange = bottom_flange
##############################
# Elastic section properties #
##############################
        
        self.Ag = (self.top_flange_L.shape.cross_sectional_area+\
                    self.top_flange_R.shape.cross_sectional_area+\
                        self.web_L.shape.cross_sectional_area+\
                            self.web_R.shape.cross_sectional_area+\
                                self.bottom_flange.shape.cross_sectional_area)*ureg('m**2')
        
        self.dna_g = (self.top_flange_L.shape.centroid[1]*self.top_flange_L.shape.cross_sectional_area+\
                      self.top_flange_R.shape.centroid[1]*self.top_flange_R.shape.cross_sectional_area+\
                      self.web_L.shape.centroid[1]*self.web_L.shape.cross_sectional_area+\
                      self.web_R.shape.centroid[1]*self.web_R.shape.cross_sectional_area+\
                      self.bottom_flange.shape.centroid[1]*self.bottom_flange.shape.cross_sectional_area)*ureg('m**3')\
                      /-self.Ag
        
        self.I_g = (self.top_flange_L.shape.moment_of_inertia[0]+\
                    self.top_flange_L.shape.cross_sectional_area*(self.dna_g.m+self.top_flange_L.shape.centroid[1])**2+\
                        self.top_flange_R.shape.moment_of_inertia[0]+\
                        self.top_flange_R.shape.cross_sectional_area*(self.dna_g.m+self.top_flange_R.shape.centroid[1])**2+\
                            self.web_L.shape.moment_of_inertia[0]+\
                            self.web_L.shape.cross_sectional_area*(self.dna_g.m+self.web_L.shape.centroid[1])**2+\
                                self.web_R.shape.moment_of_inertia[0]+\
                                self.web_R.shape.cross_sectional_area*(self.dna_g.m+self.web_R.shape.centroid[1])**2+\
                                    self.bottom_flange.shape.moment_of_inertia[0]+\
                                    self.bottom_flange.shape.cross_sectional_area*(self.dna_g.m+self.bottom_flange.shape.centroid[1])**2)\
                                        *ureg('m**4')
        
        def ElasticProperties(elements:list[Polygon]):
            fmoa = 0    # First moment of area
            smoa = 0    # Second moment of area
            A = 0
            for el in elements:
                A += el.cross_sectional_area
            
            for el in elements:
                fmoa += el.cross_sectional_area*el.centroid[1]
            dna = fmoa/-A

            for el in elements:
                smoa += el.moment_of_inertia[0]+el.cross_sectional_area*(dna+el.centroid[1])**2
          
            return A*ureg('m**2'), dna*ureg('m'), smoa*ureg('m**4')



        self.gross_section_elements: list[Polygon] = [self.top_flange_L.shape,
                                                    self.top_flange_R.shape,
                                                    self.web_L.shape,
                                                    self.web_R.shape,
                                                    self.bottom_flange.shape]

        self.Ag, self.dna_g, self.I_g = (ElasticProperties(self.gross_section_elements))




##########################
# Web effective sections #
##########################
        self.matred = Material('Steel', color = Color.red())

        self.web_re = (self.dna_g-self.top_flange_L.flange.t)/(self.web_L.geometry.D-self.top_flange_L.flange.t-self.bottom_flange.flange.t)
        self.web_ley = 60/self.web_re

        self.web_d_below_NA = self.top_flange_L.geometry.D-self.dna_g-self.bottom_flange.flange.t
        self.web_d_above_NA = self.dna_g-self.top_flange_L.flange.t
        self.d1 = self.web_d_below_NA+self.web_d_above_NA 
        
        if self.web_L.plate_element_slenderness>self.web_ley:
            self.web_lower_d_ef = self.web_d_below_NA+min(28*self.web_L.web.t/(self.web_L.web.yield_strength/(250*ureg.MPa))**0.5,self.web_d_above_NA/2)
            self.web_upper_d_ef = min(28*self.web_L.web.t/(self.web_L.web.yield_strength/(250*ureg.MPa))**0.5,self.web_d_above_NA/2)
        else:
            self.web_lower_d_ef = self.web_d_below_NA+self.web_d_above_NA/2
            self.web_upper_d_ef = self.web_d_above_NA/2
        
        #############
        # Left Side #
        #############
        self.web_x_at_upper_d_ef = (self.web_L.shape.points[0][0] + (self.web_upper_d_ef).m*tan(self.web_L.slope))
          
        self.web_L_top_ef = Polygon(([self.web_L.shape.points[0],
                                      self.web_L.shape.points[1],
                                      Point(self.web_x_at_upper_d_ef+self.web_L.web.t.m/cos(self.web_L.slope),-self.web_upper_d_ef.m-self.top_flange_L.flange.t.m),
                                      Point(self.web_x_at_upper_d_ef,-self.web_upper_d_ef.m-self.top_flange_L.flange.t.m)
                                      ]), material = self.matred)

        self.web_x_at_lower_d_ef = (self.web_L.shape.points[3][0] - (self.web_lower_d_ef).m*tan(self.web_L.slope))
        self.web_y_at_lower_d_ef = (self.web_L.shape.points[2][1]+self.web_lower_d_ef.m)

          
        self.web_L_bot_ef = Polygon(([self.web_L.shape.points[2],
                                      self.web_L.shape.points[3],
                                      Point(self.web_x_at_lower_d_ef,self.web_y_at_lower_d_ef),
                                      Point(self.web_x_at_lower_d_ef+self.web_L.web.t.m/cos(self.web_L.slope),self.web_y_at_lower_d_ef),
                                      ]), material = self.matred)
        #############
        # Right Side #
        #############
        self.web_x_at_upper_d_ef_R = (self.web_R.shape.points[0][0] - (self.web_upper_d_ef).m*tan(self.web_R.slope))
          
        self.web_R_top_ef = Polygon(([self.web_R.shape.points[0],
                                      self.web_R.shape.points[1],
                                      Point(self.web_x_at_upper_d_ef_R-self.web_R.web.t.m/cos(self.web_R.slope),-self.web_upper_d_ef.m-self.top_flange_R.flange.t.m),
                                      Point(self.web_x_at_upper_d_ef_R,-self.web_upper_d_ef.m-self.top_flange_R.flange.t.m)
                                      ]), material = self.matred)
        
        self.web_x_at_lower_d_ef_R = (self.web_R.shape.points[3][0] + (self.web_lower_d_ef).m*tan(self.web_R.slope))
        self.web_y_at_lower_d_ef_R = (self.web_R.shape.points[2][1] + self.web_lower_d_ef.m)

          
        self.web_R_bot_ef = Polygon(([self.web_R.shape.points[2],
                                      self.web_R.shape.points[3],
                                      Point(self.web_x_at_lower_d_ef_R,self.web_y_at_lower_d_ef_R),
                                      Point(self.web_x_at_lower_d_ef_R - self.web_R.web.t.m/cos(self.web_R.slope),self.web_y_at_lower_d_ef_R),
                                      ]), material = self.matred)
        
        
        
        
        
        self.effective_section_elements: list[Polygon] = [self.top_flange_L.shape_ef,
                                                    self.top_flange_R.shape_ef,
                                                    self.web_L_top_ef,
                                                    self.web_L_bot_ef,
                                                    self.web_R_top_ef,
                                                    self.web_R_bot_ef,
                                                    self.bottom_flange.shape_ef]

        self.A_ef, self.dna_ef, self.I_ef = (ElasticProperties(self.effective_section_elements))

        #print(ElasticProperties(self.gross_section_elements))
        #print(ElasticProperties(self.effective_section_elements))

##########################################
# Calculate gross elastic section moduli #
##########################################        
        self.Zx_t = self.I_g/self.dna_g
        self.Zx_b = self.I_g/(self.web_L.geometry.D-self.dna_g)

        #print(self.Zx_t,self.Zx_b)
##############################################
# Calculate effective elastic section moduli #
##############################################        
        self.Zx_t_ef = self.I_ef/self.dna_ef
        self.Zx_b_ef = self.I_ef/(self.web_L.geometry.D-self.dna_ef)
        #print(self.Zx_t_ef,self.Zx_b_ef)




##############################
# Plastic Section Properties #
##############################################
# Calculate the depth to the equal area axis #
##############################################       
        self.dna_g_plastic = (self.Ag/2-(self.top_flange_L.shape.cross_sectional_area)*ureg('m**2')-(self.top_flange_R.shape.cross_sectional_area)*ureg('m**2'))/2/\
                                ((self.web_R.web.t)/cos(self.web_R.slope))+self.top_flange_L.flange.t
############################################################################
# Determine web polygon shapes above and below the plastic equal area axis #
############################################################################        
        self.web_x_at_NA = (self.web_L.shape.points[0][0]+(self.dna_g_plastic-self.top_flange_L.flange.t).m\
            /(self.web_L.geometry.D-self.top_flange_L.flange.t-self.bottom_flange.flange.t)\
            *(self.web_L.geometry.w_top-self.web_L.geometry.w_bot)/2)*ureg('m')
        
        self.web_L_top = Polygon([self.web_L.shape.points[0],
                                 self.web_L.shape.points[1],
                                 Point(self.web_x_at_NA.m+self.web_L.web.t.m/cos(self.web_L.slope),-self.dna_g_plastic.m),
                                 Point(self.web_x_at_NA.m,-self.dna_g_plastic.m)]
                                 )

        self.web_L_bot = Polygon([self.web_L.shape.points[2],
                                 self.web_L.shape.points[3],
                                 Point(self.web_x_at_NA.m,-self.dna_g_plastic.m),
                                 Point(self.web_x_at_NA.m+self.web_L.web.t.m/cos(self.web_L.slope),-self.dna_g_plastic.m)]                                 
                                 )

        self.web_R_top = Polygon([self.web_R.shape.points[0],
                                 self.web_R.shape.points[1],
                                 Point(-self.web_x_at_NA.m-self.web_L.web.t.m/cos(self.web_L.slope),-self.dna_g_plastic.m),
                                 Point(-self.web_x_at_NA.m,-self.dna_g_plastic.m)]
                                 )

        self.web_R_bot = Polygon([self.web_R.shape.points[2],
                                 self.web_R.shape.points[3],
                                 Point(-self.web_x_at_NA.m,-self.dna_g_plastic.m),
                                 Point(-self.web_x_at_NA.m-self.web_L.web.t.m/cos(self.web_L.slope),-self.dna_g_plastic.m)]                                 
                                 )
####################################
# Calculate plastic section moduli #
####################################        
        self.Sx_g = (\
                    top_flange_L.shape.cross_sectional_area*(self.dna_g_plastic.m+top_flange_L.shape.centroid[1])\
                     +top_flange_R.shape.cross_sectional_area*(self.dna_g_plastic.m+top_flange_R.shape.centroid[1])\
                     +self.web_L_top.cross_sectional_area*(self.dna_g_plastic.m+self.web_L_top.centroid[1])\
                     +self.web_L_bot.cross_sectional_area*(-self.dna_g_plastic.m-self.web_L_bot.centroid[1])\
                     +self.web_R_top.cross_sectional_area*(self.dna_g_plastic.m+self.web_R_top.centroid[1])\
                     +self.web_R_bot.cross_sectional_area*(-self.dna_g_plastic.m-self.web_R_bot.centroid[1])\
                     +bottom_flange.shape.cross_sectional_area*(-self.dna_g_plastic.m-bottom_flange.shape.centroid[1])\
                     )*ureg('m**3')
####################################
# Section Slenderness Calculations #
####################################
        self.web_rp = (self.dna_g_plastic-self.top_flange_L.flange.t)/(self.web_L.geometry.D-self.top_flange_L.flange.t-self.bottom_flange.flange.t)
        if self.web_rp < 0.5:
            self.web_lep = 41/self.web_rp
        else:
            self.web_lep = 111/(4.7*self.web_rp-1)

        self.web_re = (self.dna_g-self.top_flange_L.flange.t)/(self.web_L.geometry.D-self.top_flange_L.flange.t-self.bottom_flange.flange.t)
        self.web_ley = 60/self.web_re

        self.web_slenderness_ratio = self.web_L.plate_element_slenderness/self.web_ley
        self.top_flange_slenderness_ratio = self.top_flange_L.slenderness_ratio
        self.bot_flange_slenderness_ratio = self.bottom_flange.slenderness_ratio
######################################################################
# Sagging Bending section slenderness - bottom flange in tension #####
######################################################################
        if self.web_slenderness_ratio > self.top_flange_slenderness_ratio:
            self.lsy = self.web_ley
            self.lsp = self.web_lep
            self.ls = self.web_L.plate_element_slenderness
        else:
            self.lsy = self.top_flange_L.ley
            self.lsp = self.top_flange_L.lep
            self.ls = self.top_flange_L.plate_element_slenderness

        if self.ls<self.lsp:
            self.compact_status_sag = 'Section is compact'
            self.Zex = min(self.Sx_g, 1.5*min(self.Zx_t,self.Zx_b))
            self.bending_capacity_x_sag = 0.9*self.Zex*min(self.bottom_flange.flange.yield_strength, self.top_flange_L.flange.yield_strength, self.web_L.web.yield_strength)
        else:
            self.compact_status_sag = 'Section is not compact under sagging moment'
            self.bending_capacity_x_sag = 0*ureg('newton*m')
######################################################################
# Hogging Bending section slenderness - top flange in tension ########
######################################################################
        if self.web_slenderness_ratio > self.bot_flange_slenderness_ratio:
            self.lsy = self.web_ley
            self.lsp = self.web_lep
            self.ls = self.web_L.plate_element_slenderness
        else:
            self.lsy = self.bottom_flange.ley
            self.lsp = self.bottom_flange.lep
            self.ls = self.bottom_flange.plate_element_slenderness
        
        if self.ls<self.lsp:
            self.compact_status_hog = 'Section is compact'
            self.Zex = min(self.Sx_g, 1.5*min(self.Zx_t,self.Zx_b))
            self.bending_capacity_x_hog = 0.9*self.Zex*min(self.bottom_flange.flange.yield_strength, self.top_flange_L.flange.yield_strength, self.web_L.web.yield_strength)
        else:
            self.compact_status_hog = 'Section is not compact under hogging moment'
            self.bending_capacity_x_hog = 0*ureg('newton*m')
##################################################
# Determine top flange effective geometry in sag #
##################################################

def TopFlangeSag_bef():
    def __init__(self, top_flange:TopFlange1):
        self.top_flange = top_flange
        effective_outstand_width = self.top_flange.flange.b/2*
    







    def calculate_section_modulus(self):
        slenderness_values = [
            self.top_flange.b / (2 * self.top_flange.t),
            self.web.b / (2 * self.web.t),
            self.bottom_flange.b / (2 * self.bottom_flange.t)
        ]
        min_slenderness = min(slenderness_values)
        elastic_modulus = min(
            self.top_flange.calculate_section_modulus(min_slenderness),
            self.web.calculate_section_modulus(min_slenderness),
            self.bottom_flange.calculate_section_modulus(min_slenderness)
        )
        plastic_modulus = min(
            self.top_flange.calculate_section_modulus(self.top_flange.plastic_slenderness_limit),
            self.web.calculate_section_modulus(self.web.plastic_slenderness_limit),
            self.bottom_flange.calculate_section_modulus(self.bottom_flange.plastic_slenderness_limit)
        )
        return elastic_modulus, plastic_modulus

# Example usage:
top_flange = TopFlange(b=10, t=0.5, yield_strength=250, elastic_slenderness_limit=120, plastic_slenderness_limit=200)
web = Web(b=20, t=0.75, yield_strength=300, elastic_slenderness_limit=150, plastic_slenderness_limit=250)
bottom_flange = BottomFlange(b=10, t=0.5, yield_strength=250, elastic_slenderness_limit=120, plastic_slenderness_limit=200)

section = TroughGirderSection(top_flange, web, bottom_flange)
elastic_modulus, plastic_modulus = section.calculate_section_modulus()
print("Elastic Section Modulus:", elastic_modulus)
print("Plastic Section Modulus:", plastic_modulus)
"""