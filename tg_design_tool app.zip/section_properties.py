from viktor.geometry import Point, Vector, Material, Color ,  Polygon
from shapely import Polygon
from sectionproperties.pre import Geometry, CompoundGeometry
#from sectionproperties.pre import rectangular_section
from sectionproperties.analysis import Section
from unit_registry import ureg, Q_


class tg_section_props():
    def __init__(self, polygons:list[Polygon]) -> None:
        self.polygons = polygons
        
        geo_polygons = []
        for polygon in polygons:
            vertices =[]
            for p in polygon.points:
                vertex = (p.x, p.y)
                vertices.append(vertex)
            poly = Polygon(vertices)
            geom = Geometry(poly)
            geo_polygons.append(geom)
        combined_geom = CompoundGeometry(geoms = geo_polygons)
        sec = combined_geom.create_mesh(10)
        sec = Section(sec)
        sec.calculate_geometric_properties()
        sec.calculate_plastic_properties()
        self.A = sec.get_area()
        self.dNA = -sec.get_c()[1]
        self.Ix = sec.get_ic()[0]
        self.dEAA = -sec.get_pc()[1]
        self.Zx_top = sec.get_z()[0]
        self.Zx_bot = sec.get_z()[1]
        if sec.get_phi() == 0.0:
            self.Zx = min(sec.get_z()[0],sec.get_z()[1])*ureg('m**3')
            self.sx = sec.get_sp()[0]*ureg('m**3')
            self.Zex = min(1.5*min(sec.get_z()[0],sec.get_z()[1]),sec.get_sp()[0])*ureg('m**3')
        else:
            self.Zx = min(sec.get_z()[0],sec.get_z()[1])*ureg('m**3')
            self.Zex = min(1.5*min(sec.get_z()[0],sec.get_z()[1]),sec.get_sp()[1])*ureg('m**3')
            self.sx = sec.get_sp()[1]*ureg('m**3')
       